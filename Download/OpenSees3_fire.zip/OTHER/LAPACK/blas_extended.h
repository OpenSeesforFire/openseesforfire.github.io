#ifndef BLAS_EXTENDED_H
#define BLAS_EXTENDED_H

#include "blas_enum.h"
#include "blas_malloc.h"

#include "blas_extended_proto.h"
#include "blas_dense_proto.h"

#endif /* BLAS_EXTENDED_H */
