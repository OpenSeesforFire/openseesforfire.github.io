## Revision log
## 07/31 remove node of column B2

# Horizionatal beam nodes
set h610 [expr -0.5*$h_UB610 - $h_rib -0.5*$h_slab]
set h356 [expr -0.5*$h_UB356 - $h_rib -0.5*$h_slab]
set h305 [expr -0.5*$h_UB305 - $h_rib -0.5*$h_slab]
set h254 [expr -0.5*$h_UB254 - $h_rib -0.5*$h_slab]
set hSlab 0

set endNode1 17
set endNode2 49
set endNode3 81
for {set i 1} {$i <= $endNode1} {incr i 1} {
    if {$i == 1} {
        set x [expr -($i - 1.0)*$elemL]
    } elseif {$i < $endNode1} {
        set x [expr -($i - 1.5)*$elemL]
    } else {
        set x [expr -($i - 2.0)*$elemL]
    }
    node [expr $i + 100] $x $A1y $h356
    node [expr $i + 200] $x [expr ($A1y + $A2y)*0.5] $h305
    node [expr $i + 300] $x $A2y $h305
    node [expr $i + 400] $x -3000.0 $h356
    node [expr $i + 900] $x 0 $h356
    node [expr $i + 500] $x 1500 $h305
    node [expr $i + 600] $x $A3y $h356
    node [expr $i + 700] $x [expr ($A3y + $A4y)*0.5] $h305
    node [expr $i + 800] $x $A4y $h356
}

for {set i [expr $endNode1 + 1]} {$i <= $endNode2} {incr i 1} {
    if {$i == [expr $endNode1 + 1]} {
        set x [expr -($i - 3.0)*$elemL]
    } elseif {$i < $endNode2} {
        set x [expr -($i - 3.5)*$elemL]
    } else {
        set x [expr -($i - 4.0)*$elemL]
    }
    node [expr $i + 100] $x $A1y $h356
    node [expr $i + 200] $x [expr ($A1y + $A2y)*0.5] $h305
    node [expr $i + 300] $x $A2y $h305
    node [expr $i + 400] $x -1500.0 $h305
    node [expr $i + 500] $x 1500 $h305
    node [expr $i + 600] $x $A3y $h305
    node [expr $i + 700] $x [expr ($A3y + $A4y)*0.5] $h305
    node [expr $i + 800] $x $A4y $h356
}

for {set i [expr $endNode2 + 1]} {$i <= $endNode3} {incr i 1} {
    if {$i == [expr $endNode2 + 1]} {
        set x [expr -($i - 5.0)*$elemL]
    } elseif {$i < $endNode3} {
        set x [expr -($i - 5.5)*$elemL]
    } elseif {$i == $endNode3} {
        set x [expr -($i - 6.0)*$elemL]
    }
    node [expr $i + 100] $x $A1y $h356
    node [expr $i + 200] $x [expr ($A1y + $A2y)*0.5] $h305
    node [expr $i + 300] $x $A2y $h305
    if {abs($x) <= abs($AB23x)} { 
        node [expr $i + 400] $x -1500.0 $h305
        node [expr $i + 500] $x 1500.0 $h305
        node [expr $i + 600] $x $A3y $h305
        if {abs($x) == abs($AB23x)} { 
            set nodesAB [expr $i + 1]
        }
    }
    node [expr $i + 700] $x [expr ($A3y + $A4y)*0.5] $h305
    node [expr $i + 800] $x $A4y $h356
}

for {set i $nodesAB} {$i <= [expr $endNode3 + 1]} {incr i 1} {
    if {$i >= $nodesAB && $i < [expr $endNode3 + 1]} {
        set x [expr -($i - 6.5)*$elemL]
    } elseif {$i == [expr $endNode3 + 1]} {
        set x [expr -($i - 7.0)*$elemL]
    }
    node [expr $i + 600] $x $A3y $h356
    node [expr $i + 900] $x $A23y $h356
    node [expr $i + 500] $x -1500 $h356
    node [expr $i + 400] $x $AB23y $h356
}

# Vertical beam nodes
set endNode1v 21
set endNode2v 37
set endNode3v 53
set endNode4v 74
for {set i 1} {$i <= $endNode4v} {incr i 1} {
    if {$i <= $endNode1v} {
        set y [expr -10500.0 + ($i - 1.0)*$elemL]
        set h $h356
    } elseif {$i <= $endNode2v} {
        set y [expr -10500.0 + ($i - 2.0)*$elemL]
        set h $h610
    } elseif {$i <= $endNode3v} {
        set y [expr -10500.0 + ($i - 3.0)*$elemL]
        set h $h610
    } elseif {$i <= $endNode4v} {
        set y [expr -10500.0 + ($i - 4.0)*$elemL]
        set h $h356
    }
    node [expr $i + 1100] $C1x $y $h356
    node [expr $i + 1200] $B1x $y $h
    node [expr $i + 1300] $A1x $y $h356
}

# beam 1500
set endNode5v 8
set endNode6v 32
for {set i 1} {$i <= $endNode6v} {incr i 1} {
    if {$i <= $endNode5v} {
        set y [expr -4500.0 + ($i - 1.0)*$elemL]
    } elseif {$i <= $endNode6v} {
        set y [expr -4500.0 + ($i - 2.0)*$elemL]
    }
    node [expr $i + 1500] $AB23x $y $h356
}

# beam 1400
for {set i 1} {$i <= 16} {incr i 1} {
    set y [expr ($i - 1.0)*$elemL]
    node [expr $i + 1400] 0 $y $h356
}

for {set i 1} {$i <= 11} {incr i 1} {
    set y [expr -3000.0 + ($i - 1.0)*$elemL]
    node [expr $i + 1600] -750 $y $h356
    node [expr $i + 1700] -3450 $y $h356
}

# Columns
for {set i 1} {$i <= [expr 1 + abs($zlimf - $zlimi)/$colL]} {incr i 1} {
    set z [expr $zlimi + ($i - 1)*$colL]
    node [expr $i + 2100] $CD23x $CD23y $z
    node [expr $i + 2200] $C1x $C1y $z
    node [expr $i + 2300] $C2x $C2y $z
    node [expr $i + 2400] $C23x $C23y $z
    node [expr $i + 2500] $C3x $C3y $z
    node [expr $i + 2600] $C4x $C4y $z
    node [expr $i + 2700] $B1x $B1y $z
    node [expr $i + 3000] $B4x $B4y $z
    node [expr $i + 3100] $AB23x $AB23y $z
    node [expr $i + 3200] $AB3x $AB3y $z
    node [expr $i + 3300] $A1x $A1y $z
    node [expr $i + 3400] $A2x $A2y $z
    node [expr $i + 3500] $A23x $A23y $z
    node [expr $i + 3600] $A3x $A3y $z
    node [expr $i + 3700] $A4x $A4y $z
}

# Columns of interest - MUSTESIN
for {set i 1} {$i <= 25} {incr i 1} {
    if {$i < 7} {
        set z [expr $zlimi + ($i - 1)*$colL]
    } elseif {$i >= 7 && $i <= 17} {
        set z [expr -1000.0 + 100.0*($i - 7)]
    } else { 
        set z [expr ($i - 17)*$colL]
    }
    node [expr $i + 2800] $B2x $B2y $z
    node [expr $i + 2900] $B3x $B3y $z
}
## 21.07.02
for {set i 2} {$i < 17} {incr i 1} {
    remove node [expr $i + 2800]
}
for {set i 2} {$i < 17} {incr i 1} {
    remove node [expr $i + 2900]
}

# Slab
for {set i 1} {$i <= 79} {incr i} {
    for {set j 1} {$j <= 71} {incr j} {
        if {$i == 1} {
            set x [expr -($i - 1.0)*$elemL]
        } elseif {$i < 17} {
            set x [expr -($i - 1.5)*$elemL]
        } elseif {$i == 17} {
            set x [expr -($i - 2.0)*$elemL]
        } elseif {$i < 48} {
            set x [expr -($i - 2.5)*$elemL]
        } elseif {$i == 48} {
            set x [expr -($i - 3.0)*$elemL]
        } elseif {$i < 79} {
            set x [expr -($i - 3.5)*$elemL]
        } elseif {$i == 79} {
            set x [expr -($i - 4.0)*$elemL]
        }
        set y [expr -10500 + ($j - 1)*$elemL]
        set nodeID [expr 4000 + ($i - 1)*1000 + $j]
        if {$i < 17 && $j > 26 && $j < 36} {
            # opening
        } elseif {$i > 65 && $j > 36 && $j < 51} {
            # opening
        } else {
            node $nodeID $x $y $hSlab
        }
    }
}   

## remove node of column B2
for {set i 2} {$i <= 16} {incr i} {
    remove node [expr ($i + 2800)]
} 
for {set i 2} {$i <= 16} {incr i} {
    remove node [expr ($i + 2900)]
} 