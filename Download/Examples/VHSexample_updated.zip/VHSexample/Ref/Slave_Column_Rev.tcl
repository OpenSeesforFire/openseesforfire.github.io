


wipe;

# ------------------------------
# Start of model generation
# ------------------------------
# create ModelBuilder (with two-dimensions and 2 DOF/node)

## 0524 Make sure the system coordinate is same as master.tcl
model BasicBuilder -ndm 3 -ndf 6
# Load OpenFresco package
# -----------------------
# (make sure all dlls are in the same folder as openSees.exe)
loadPackage OpenFresco

# Define geometry for model Nodes of 1 flange



# -------------------------
# node $tag $xCrd $yCrd
# Define materials

source DisplayPlane.tcl
source DisplayModel2D.tcl
source DisplayModel3D.tcl

#source LibUnits.tcl;           # define units
#source DisplayPlane.tcl;       # procedure for displaying a plane in model
#source DisplayModel3D.tcl; 


set K 1.3e11;
set G 0.75e11;
set sig0 455e6;
set sigInf 555e6;

set delta 1;
set H 0;

#set delta2 0;
set mDen  7800;


#nDMaterial J2Thermal 4 3 $K $G $sig0 $sigInf $delta $H 0;

# Another option for J2 plasticity
#nDMaterial  J2PlaneStressThermal $tag $typeTag $nu $fy $fu $hardening factor
nDMaterial  J2PlaneStressThermal 4 3 2e11 0.3 4.68e8 6.00e8 0.1 2e8;
#nDMaterial   PlateFromPlaneStressThermal    2   4   20e10;
nDMaterial   PlateFromPlaneStressThermal    2   4   20e4;

    # // EN 1992&1993
    # //typeTag:3   EC3 Structural Steel
    # //typeTag:21  EC2 Reinforcing Steel EC2 NHotRolled
    # //typeTag:22  EC2 Reinforcing Steel EC2 NCold formed
    # //typeTag:23  EC2 Reinforcing Steel EC2 X


#set sigInf 44960;

#nDMaterial DruckerPragerThermal 3 2.4e10 1.3e10 7.6e6 $rho $rhoBar $Kinf $K0 1 1 $h 1 $mDen1;
#nDMaterial ElasticIsotropic3DThermal $matTag 2.9e7 0.3 0 1.4e-5;
nDMaterial CDPPlaneStressThermal 3 3.15e10 0.15 4.4e6 4.0e7 9.3e5  3.16e8;
#nDMaterial ElasticIsotropic3DThermal 3 2.9e10 0.3 0 1.4e-5;

nDMaterial   PlateFromPlaneStressThermal    1 3   10e8;

#nDMaterial PlateFiberThermal 2 4;
#nDMaterial PlateFiberThermal 1 3;

#uniaxialMaterial Steel01Thermal 8 475 2.1e11 0.01;
# section: $secTag $matTag $thickness
uniaxialMaterial SteelECThermal 8 EC2NH 4.60e8 2e11;
#uniaxialMaterial ElasticThermal 1 2e11 1.2e-5;
nDMaterial PlateRebarThermal 9 8 0;  # Transverse steel.
nDMaterial PlateRebarThermal 10 8 90; #longitudinal steel.

#section LayeredShellThermal  5  8  2 0.001  10  0.00015 9  0.00015   1 0.009 1  0.0097  1  0.02 1  0.01 1  0.01     ;
section LayeredShellThermal  5  7 1  0.02 10  0.0005 9  0.0005 1  0.009 1  0.01  1  0.01  1  0.006    ;

#section PlateFiberThermal 5 2 0.12;

# On 0524
#section LayeredShellThermal  3  4  2  0.004  2  0.004 2  0.004 2  0.004   ;
#section LayeredShellThermal  2  4  2  0.003 2   0.003 2  0.003 2  0.003;

section LayeredShellThermal  3  4  2  4  2  4 2  4 2  4   ;
section LayeredShellThermal  2  4  2  3  2  3 2  3 2  3   ;

section LayeredShellThermal  6  4  2  0.0035 2  0.0035  2 0.0035  2 0.0035;
section LayeredShellThermal  7  5  2  0.00472  2  0.00472  2  0.00472  2  0.00472  2  0.00472   ;

#node    1   0   0   0
#node    2   0   0.083333333 0
#node    3   0   0.291666667 0
#node    4   0   0.375   0
#node    5   0   0.458333333 0
#node    6   0   0.666666667 0
#node    7   0   0.75    0
#node    8   0   0.833333333 0
#node    9   0   1.041666667 0
#node    10  0   1.125   0
#node    11  0   1.208333333 0
#node    12  0   1.416666667 0
#node    13  0   1.5 0
#node    14  0   1.583333333 0
#node    15  0   1.791666667 0
#node    16  0   1.875   0
#node    17  0   1.958333333 0
#node    18  0   2.166666667 0
#node    19  0   2.25    0
#node    20  0   2.333333333 0
#node    21  0   2.541666667 0
#node    22  0   2.625   0
#node    23  0   2.708333333 0
#node    24  0   2.916666667 0
#node    25  0   3   0
#node    26  0.1 0   0
#node    27  0.1 0.083333333 0
#node    28  0.1 0.291666667 0
#node    29  0.1 0.375   0
#node    30  0.1 0.458333333 0
#node    31  0.1 0.666666667 0
#node    32  0.1 0.75    0
#node    33  0.1 0.833333333 0
#node    34  0.1 1.041666667 0
#node    35  0.1 1.125   0
#node    36  0.1 1.208333333 0
#node    37  0.1 1.416666667 0
#node    38  0.1 1.5 0
#node    39  0.1 1.583333333 0
#node    40  0.1 1.791666667 0
#node    41  0.1 1.875   0
#node    42  0.1 1.958333333 0
#node    43  0.1 2.166666667 0
#node    44  0.1 2.25    0
#node    45  0.1 2.333333333 0
#node    46  0.1 2.541666667 0
#node    47  0.1 2.625   0
#node    48  0.1 2.708333333 0
#node    49  0.1 2.916666667 0
#node    50  0.1 3   0
#node    51  0.2 0   0
#node    52  0.2 0.083333333 0
#node    53  0.2 0.291666667 0
#node    54  0.2 0.375   0
#node    55  0.2 0.458333333 0
#node    56  0.2 0.666666667 0
#node    57  0.2 0.75    0
#node    58  0.2 0.833333333 0
#node    59  0.2 1.041666667 0
#node    60  0.2 1.125   0
#node    61  0.2 1.208333333 0
#node    62  0.2 1.416666667 0
#node    63  0.2 1.5 0
#node    64  0.2 1.583333333 0
#node    65  0.2 1.791666667 0
#node    66  0.2 1.875   0
#node    67  0.2 1.958333333 0
#node    68  0.2 2.166666667 0
#node    69  0.2 2.25    0
#node    70  0.2 2.333333333 0
#node    71  0.2 2.541666667 0
#node    72  0.2 2.625   0
#node    73  0.2 2.708333333 0
#node    74  0.2 2.916666667 0
#node    75  0.2 3   0
#node    76  -0.1    0   0
#node    77  -0.1    0.083333333 0
#node    78  -0.1    0.291666667 0
#node    79  -0.1    0.375   0
#node    80  -0.1    0.458333333 0
#node    81  -0.1    0.666666667 0
#node    82  -0.1    0.75    0
#node    83  -0.1    0.833333333 0
#node    84  -0.1    1.041666667 0
#node    85  -0.1    1.125   0
#node    86  -0.1    1.208333333 0
#node    87  -0.1    1.416666667 0
#node    88  -0.1    1.5 0
#node    89  -0.1    1.583333333 0
#node    90  -0.1    1.791666667 0
#node    91  -0.1    1.875   0
#node    92  -0.1    1.958333333 0
#node    93  -0.1    2.166666667 0
#node    94  -0.1    2.25    0
#node    95  -0.1    2.333333333 0
#node    96  -0.1    2.541666667 0
#node    97  -0.1    2.625   0
#node    98  -0.1    2.708333333 0
#node    99  -0.1    2.916666667 0
#node    100 -0.1    3   0
#node    101 -0.2    0   0
#node    102 -0.2    0.083333333 0
#node    103 -0.2    0.291666667 0
#node    104 -0.2    0.375   0
#node    105 -0.2    0.458333333 0
#node    106 -0.2    0.666666667 0
#node    107 -0.2    0.75    0
#node    108 -0.2    0.833333333 0
#node    109 -0.2    1.041666667 0
#node    110 -0.2    1.125   0
#node    111 -0.2    1.208333333 0
#node    112 -0.2    1.416666667 0
#node    113 -0.2    1.5 0
#node    114 -0.2    1.583333333 0
#node    115 -0.2    1.791666667 0
#node    116 -0.2    1.875   0
#node    117 -0.2    1.958333333 0
#node    118 -0.2    2.166666667 0
#node    119 -0.2    2.25    0
#node    120 -0.2    2.333333333 0
#node    121 -0.2    2.541666667 0
#node    122 -0.2    2.625   0
#node    123 -0.2    2.708333333 0
#node    124 -0.2    2.916666667 0
#node    125 -0.2    3   0
                
                
                
#node    126 0.2 0   0.068
#node    127 0.2 0.083333333 0.068
#node    128 0.2 0.291666667 0.068
#node    129 0.2 0.375   0.068
#node    130 0.2 0.458333333 0.068
#node    131 0.2 0.666666667 0.068
#node    132 0.2 0.75    0.068
#node    133 0.2 0.833333333 0.068
#node    134 0.2 1.041666667 0.068
#node    135 0.2 1.125   0.068
#node    136 0.2 1.208333333 0.068
#node    137 0.2 1.416666667 0.068
#node    138 0.2 1.5 0.068
#node    139 0.2 1.583333333 0.068
#node    140 0.2 1.791666667 0.068
#node    141 0.2 1.875   0.068
#node    142 0.2 1.958333333 0.068
#node    143 0.2 2.166666667 0.068
#node    144 0.2 2.25    0.068
#node    145 0.2 2.333333333 0.068
#node    146 0.2 2.541666667 0.068
#node    147 0.2 2.625   0.068
#node    148 0.2 2.708333333 0.068
#node    149 0.2 2.916666667 0.068
#node    150 0.2 3   0.068
#node    151 0.2 0   -0.068
#node    152 0.2 0.083333333 -0.068
#node    153 0.2 0.291666667 -0.068
#node    154 0.2 0.375   -0.068
#node    155 0.2 0.458333333 -0.068
#node    156 0.2 0.666666667 -0.068
#node    157 0.2 0.75    -0.068
#node    158 0.2 0.833333333 -0.068
#node    159 0.2 1.041666667 -0.068
#node    160 0.2 1.125   -0.068
#node    161 0.2 1.208333333 -0.068
#node    162 0.2 1.416666667 -0.068
#node    163 0.2 1.5 -0.068
#node    164 0.2 1.583333333 -0.068
#node    165 0.2 1.791666667 -0.068
#node    166 0.2 1.875   -0.068
#node    167 0.2 1.958333333 -0.068
#node    168 0.2 2.166666667 -0.068
#node    169 0.2 2.25    -0.068
#node    170 0.2 2.333333333 -0.068
#node    171 0.2 2.541666667 -0.068
#node    172 0.2 2.625   -0.068
#node    173 0.2 2.708333333 -0.068
#node    174 0.2 2.916666667 -0.068
#node    175 0.2 3   -0.068
#node    176 -0.2    0   0.068
#node    177 -0.2    0.083333333 0.068
#node    178 -0.2    0.291666667 0.068
#node    179 -0.2    0.375   0.068
#node    180 -0.2    0.458333333 0.068
#node    181 -0.2    0.666666667 0.068
#node    182 -0.2    0.75    0.068
#node    183 -0.2    0.833333333 0.068
#node    184 -0.2    1.041666667 0.068
#node    185 -0.2    1.125   0.068
#node    186 -0.2    1.208333333 0.068
#node    187 -0.2    1.416666667 0.068
#node    188 -0.2    1.5 0.068
#node    189 -0.2    1.583333333 0.068
#node    190 -0.2    1.791666667 0.068
#node    191 -0.2    1.875   0.068
#node    192 -0.2    1.958333333 0.068
#node    193 -0.2    2.166666667 0.068
#node    194 -0.2    2.25    0.068
#node    195 -0.2    2.333333333 0.068
#node    196 -0.2    2.541666667 0.068
#node    197 -0.2    2.625   0.068
#node    198 -0.2    2.708333333 0.068
#node    199 -0.2    2.916666667 0.068
#node    200 -0.2    3   0.068
#node    201 -0.2    0   -0.068
#node    202 -0.2    0.083333333 -0.068
#node    203 -0.2    0.291666667 -0.068
#node    204 -0.2    0.375   -0.068
#node    205 -0.2    0.458333333 -0.068
#node    206 -0.2    0.666666667 -0.068
#node    207 -0.2    0.75    -0.068
#node    208 -0.2    0.833333333 -0.068
#node    209 -0.2    1.041666667 -0.068
#node    210 -0.2    1.125   -0.068
#node    211 -0.2    1.208333333 -0.068
#node    212 -0.2    1.416666667 -0.068
#node    213 -0.2    1.5 -0.068
#node    214 -0.2    1.583333333 -0.068
#node    215 -0.2    1.791666667 -0.068
#node    216 -0.2    1.875   -0.068
#node    217 -0.2    1.958333333 -0.068
#node    218 -0.2    2.166666667 -0.068
#node    219 -0.2    2.25    -0.068
#node    220 -0.2    2.333333333 -0.068
#node    221 -0.2    2.541666667 -0.068
#node    222 -0.2    2.625   -0.068
#node    223 -0.2    2.708333333 -0.068
#node    224 -0.2    2.916666667 -0.068
#node    225 -0.2    3   -0.068


node    1   0   0   0
node    2   0   0   166.67
node    3   0   0   333.34
node    4   0   0   500.01
node    5   0   0   666.68
node    6   0   0   833.35
node    7   0   0   1000.02
node    8   0   0   1166.69
node    9   0   0   1333.36
node    10  0   0   1500.03
node    11  0   0   1666.7
node    12  0   0   1833.37
node    13  0   0   2000.04
node    14  0   0   2166.71
node    15  0   0   2333.38
node    16  0   0   2500.05
node    17  0   0   2666.72
node    18  0   0   2833.39
node    19  0   0   3000.06
node    20  0   0   3166.73
node    21  0   0   3333.4
node    22  0   0   3500.07
node    23  0   0   3666.74
node    24  0   0   3833.41
node    25  0   0   4000
node    26  -100    0   0
node    27  -100    0   166.67
node    28  -100    0   333.34
node    29  -100    0   500.01
node    30  -100    0   666.68
node    31  -100    0   833.35
node    32  -100    0   1000.02
node    33  -100    0   1166.69
node    34  -100    0   1333.36
node    35  -100    0   1500.03
node    36  -100    0   1666.7
node    37  -100    0   1833.37
node    38  -100    0   2000.04
node    39  -100    0   2166.71
node    40  -100    0   2333.38
node    41  -100    0   2500.05
node    42  -100    0   2666.72
node    43  -100    0   2833.39
node    44  -100    0   3000.06
node    45  -100    0   3166.73
node    46  -100    0   3333.4
node    47  -100    0   3500.07
node    48  -100    0   3666.74
node    49  -100    0   3833.41
node    50  -100    0   4000
node    51  -200    0   0
node    52  -200    0   166.67
node    53  -200    0   333.34
node    54  -200    0   500.01
node    55  -200    0   666.68
node    56  -200    0   833.35
node    57  -200    0   1000.02
node    58  -200    0   1166.69
node    59  -200    0   1333.36
node    60  -200    0   1500.03
node    61  -200    0   1666.7
node    62  -200    0   1833.37
node    63  -200    0   2000.04
node    64  -200    0   2166.71
node    65  -200    0   2333.38
node    66  -200    0   2500.05
node    67  -200    0   2666.72
node    68  -200    0   2833.39
node    69  -200    0   3000.06
node    70  -200    0   3166.73
node    71  -200    0   3333.4
node    72  -200    0   3500.07
node    73  -200    0   3666.74
node    74  -200    0   3833.41
node    75  -200    0   4000
node    76  100 0   0
node    77  100 0   166.67
node    78  100 0   333.34
node    79  100 0   500.01
node    80  100 0   666.68
node    81  100 0   833.35
node    82  100 0   1000.02
node    83  100 0   1166.69
node    84  100 0   1333.36
node    85  100 0   1500.03
node    86  100 0   1666.7
node    87  100 0   1833.37
node    88  100 0   2000.04
node    89  100 0   2166.71
node    90  100 0   2333.38
node    91  100 0   2500.05
node    92  100 0   2666.72
node    93  100 0   2833.39
node    94  100 0   3000.06
node    95  100 0   3166.73
node    96  100 0   3333.4
node    97  100 0   3500.07
node    98  100 0   3666.74
node    99  100 0   3833.41
node    100 100 0   4000
node    101 200 0   0
node    102 200 0   166.67
node    103 200 0   333.34
node    104 200 0   500.01
node    105 200 0   666.68
node    106 200 0   833.35
node    107 200 0   1000.02
node    108 200 0   1166.69
node    109 200 0   1333.36
node    110 200 0   1500.03
node    111 200 0   1666.7
node    112 200 0   1833.37
node    113 200 0   2000.04
node    114 200 0   2166.71
node    115 200 0   2333.38
node    116 200 0   2500.05
node    117 200 0   2666.72
node    118 200 0   2833.39
node    119 200 0   3000.06
node    120 200 0   3166.73
node    121 200 0   3333.4
node    122 200 0   3500.07
node    123 200 0   3666.74
node    124 200 0   3833.41
node    125 200 0   4000
node    126 -200    -68 0
node    127 -200    -68 166.67
node    128 -200    -68 333.34
node    129 -200    -68 500.01
node    130 -200    -68 666.68
node    131 -200    -68 833.35
node    132 -200    -68 1000.02
node    133 -200    -68 1166.69
node    134 -200    -68 1333.36
node    135 -200    -68 1500.03
node    136 -200    -68 1666.7
node    137 -200    -68 1833.37
node    138 -200    -68 2000.04
node    139 -200    -68 2166.71
node    140 -200    -68 2333.38
node    141 -200    -68 2500.05
node    142 -200    -68 2666.72
node    143 -200    -68 2833.39
node    144 -200    -68 3000.06
node    145 -200    -68 3166.73
node    146 -200    -68 3333.4
node    147 -200    -68 3500.07
node    148 -200    -68 3666.74
node    149 -200    -68 3833.41
node    150 -200    -68 4000
node    151 -200    68  0
node    152 -200    68  166.67
node    153 -200    68  333.34
node    154 -200    68  500.01
node    155 -200    68  666.68
node    156 -200    68  833.35
node    157 -200    68  1000.02
node    158 -200    68  1166.69
node    159 -200    68  1333.36
node    160 -200    68  1500.03
node    161 -200    68  1666.7
node    162 -200    68  1833.37
node    163 -200    68  2000.04
node    164 -200    68  2166.71
node    165 -200    68  2333.38
node    166 -200    68  2500.05
node    167 -200    68  2666.72
node    168 -200    68  2833.39
node    169 -200    68  3000.06
node    170 -200    68  3166.73
node    171 -200    68  3333.4
node    172 -200    68  3500.07
node    173 -200    68  3666.74
node    174 -200    68  3833.41
node    175 -200    68  4000
node    176 200 -68 0
node    177 200 -68 166.67
node    178 200 -68 333.34
node    179 200 -68 500.01
node    180 200 -68 666.68
node    181 200 -68 833.35
node    182 200 -68 1000.02
node    183 200 -68 1166.69
node    184 200 -68 1333.36
node    185 200 -68 1500.03
node    186 200 -68 1666.7
node    187 200 -68 1833.37
node    188 200 -68 2000.04
node    189 200 -68 2166.71
node    190 200 -68 2333.38
node    191 200 -68 2500.05
node    192 200 -68 2666.72
node    193 200 -68 2833.39
node    194 200 -68 3000.06
node    195 200 -68 3166.73
node    196 200 -68 3333.4
node    197 200 -68 3500.07
node    198 200 -68 3666.74
node    199 200 -68 3833.41
node    200 200 -68 4000
node    201 200 68  0
node    202 200 68  166.67
node    203 200 68  333.34
node    204 200 68  500.01
node    205 200 68  666.68
node    206 200 68  833.35
node    207 200 68  1000.02
node    208 200 68  1166.69
node    209 200 68  1333.36
node    210 200 68  1500.03
node    211 200 68  1666.7
node    212 200 68  1833.37
node    213 200 68  2000.04
node    214 200 68  2166.71
node    215 200 68  2333.38
node    216 200 68  2500.05
node    217 200 68  2666.72
node    218 200 68  2833.39
node    219 200 68  3000.06
node    220 200 68  3166.73
node    221 200 68  3333.4
node    222 200 68  3500.07
node    223 200 68  3666.74
node    224 200 68  3833.41
node    225 200 68  4000














#fix    101 1   1   1   0   0   0
#fix    125 0   1   1   0   0   0

#fix    201 1   1   1   0   0   0
#fix    225 0   1   1   0   0   0
#fix    176 1   1   1   0   0   0
#fix    200 0   1   1   0   0   0


    
    
fix 1   1   1   1   1 1 1
fix 26  1   1   1   1 1 1
fix 51  1   1   1   1 1 1
fix 76  1   1   1   1 1 1
fix 101 1   1   1   1 1 1
fix 126 1   1   1   1 1 1

fix 151 1   1   1   1   1   1

fix 176 1   1   1   1   1   1

fix 201 1   1   1   1   1   1





#fix    1   1   1   1   0 0 0
#fix    25  1   1   1   0 0 0
#fix    51  1   1   1   0 0 0
#fix    75  1   1   1   0 0 0
#fix    101 1   1   1   0 0 0
#fix    125 1   1   1   0 0 0
#fix    26  1   1   1   0 0 0
#fix    50  1   1   1   0 0 0
#fix    76  1   1   1   0 0 0
#fix    100 1   1   1   0 0 0


#fix    126 1   1   1   0   0   0
#fix    150 1   1   1   0   0   0
#fix    151 1   1   1   0   0   0
#fix    175 1   1   1   0   0   0
#fix    176 1   1   1   0   0   0
#fix    200 1   1   1   0   0   0
#fix    201 1   1   1   0   0   0
#fix    225 1   1   1   0   0   0










#
 
#define element for traslational&rotational spring
# element ShellMITC4Thermal $eleTag $iNode $jNode $kNode $lNode $secTag;

element ShellMITC4Thermal   1   1   2   27  26  2
element ShellMITC4Thermal   2   2   3   28  27  2
element ShellMITC4Thermal   3   3   4   29  28  2
element ShellMITC4Thermal   4   4   5   30  29  2
element ShellMITC4Thermal   5   5   6   31  30  2
element ShellMITC4Thermal   6   6   7   32  31  2
element ShellMITC4Thermal   7   7   8   33  32  2
element ShellMITC4Thermal   8   8   9   34  33  2
element ShellMITC4Thermal   9   9   10  35  34  2
element ShellMITC4Thermal   10  10  11  36  35  2
element ShellMITC4Thermal   11  11  12  37  36  2
element ShellMITC4Thermal   12  12  13  38  37  2
element ShellMITC4Thermal   13  13  14  39  38  2
element ShellMITC4Thermal   14  14  15  40  39  2
element ShellMITC4Thermal   15  15  16  41  40  2
element ShellMITC4Thermal   16  16  17  42  41  2
element ShellMITC4Thermal   17  17  18  43  42  2
element ShellMITC4Thermal   18  18  19  44  43  2
element ShellMITC4Thermal   19  19  20  45  44  2
element ShellMITC4Thermal   20  20  21  46  45  2
element ShellMITC4Thermal   21  21  22  47  46  2
element ShellMITC4Thermal   22  22  23  48  47  2
element ShellMITC4Thermal   23  23  24  49  48  2
element ShellMITC4Thermal   24  24  25  50  49  2
element ShellMITC4Thermal   25  26  27  52  51  2
element ShellMITC4Thermal   26  27  28  53  52  2
element ShellMITC4Thermal   27  28  29  54  53  2
element ShellMITC4Thermal   28  29  30  55  54  2
element ShellMITC4Thermal   29  30  31  56  55  2
element ShellMITC4Thermal   30  31  32  57  56  2
element ShellMITC4Thermal   31  32  33  58  57  2
element ShellMITC4Thermal   32  33  34  59  58  2
element ShellMITC4Thermal   33  34  35  60  59  2
element ShellMITC4Thermal   34  35  36  61  60  2
element ShellMITC4Thermal   35  36  37  62  61  2
element ShellMITC4Thermal   36  37  38  63  62  2
element ShellMITC4Thermal   37  38  39  64  63  2
element ShellMITC4Thermal   38  39  40  65  64  2
element ShellMITC4Thermal   39  40  41  66  65  2
element ShellMITC4Thermal   40  41  42  67  66  2
element ShellMITC4Thermal   41  42  43  68  67  2
element ShellMITC4Thermal   42  43  44  69  68  2
element ShellMITC4Thermal   43  44  45  70  69  2
element ShellMITC4Thermal   44  45  46  71  70  2
element ShellMITC4Thermal   45  46  47  72  71  2
element ShellMITC4Thermal   46  47  48  73  72  2
element ShellMITC4Thermal   47  48  49  74  73  2
element ShellMITC4Thermal   48  49  50  75  74  2
element ShellMITC4Thermal   49  76  77  2   1   2
element ShellMITC4Thermal   50  77  78  3   2   2
element ShellMITC4Thermal   51  78  79  4   3   2
element ShellMITC4Thermal   52  79  80  5   4   2
element ShellMITC4Thermal   53  80  81  6   5   2
element ShellMITC4Thermal   54  81  82  7   6   2
element ShellMITC4Thermal   55  82  83  8   7   2
element ShellMITC4Thermal   56  83  84  9   8   2
element ShellMITC4Thermal   57  84  85  10  9   2
element ShellMITC4Thermal   58  85  86  11  10  2
element ShellMITC4Thermal   59  86  87  12  11  2
element ShellMITC4Thermal   60  87  88  13  12  2
element ShellMITC4Thermal   61  88  89  14  13  2
element ShellMITC4Thermal   62  89  90  15  14  2
element ShellMITC4Thermal   63  90  91  16  15  2
element ShellMITC4Thermal   64  91  92  17  16  2
element ShellMITC4Thermal   65  92  93  18  17  2
element ShellMITC4Thermal   66  93  94  19  18  2
element ShellMITC4Thermal   67  94  95  20  19  2
element ShellMITC4Thermal   68  95  96  21  20  2
element ShellMITC4Thermal   69  96  97  22  21  2
element ShellMITC4Thermal   70  97  98  23  22  2
element ShellMITC4Thermal   71  98  99  24  23  2
element ShellMITC4Thermal   72  99  100 25  24  2
element ShellMITC4Thermal   73  101 102 77  76  2
element ShellMITC4Thermal   74  102 103 78  77  2
element ShellMITC4Thermal   75  103 104 79  78  2
element ShellMITC4Thermal   76  104 105 80  79  2
element ShellMITC4Thermal   77  105 106 81  80  2
element ShellMITC4Thermal   78  106 107 82  81  2
element ShellMITC4Thermal   79  107 108 83  82  2
element ShellMITC4Thermal   80  108 109 84  83  2
element ShellMITC4Thermal   81  109 110 85  84  2
element ShellMITC4Thermal   82  110 111 86  85  2
element ShellMITC4Thermal   83  111 112 87  86  2
element ShellMITC4Thermal   84  112 113 88  87  2
element ShellMITC4Thermal   85  113 114 89  88  2
element ShellMITC4Thermal   86  114 115 90  89  2
element ShellMITC4Thermal   87  115 116 91  90  2
element ShellMITC4Thermal   88  116 117 92  91  2
element ShellMITC4Thermal   89  117 118 93  92  2
element ShellMITC4Thermal   90  118 119 94  93  2
element ShellMITC4Thermal   91  119 120 95  94  2
element ShellMITC4Thermal   92  120 121 96  95  2
element ShellMITC4Thermal   93  121 122 97  96  2
element ShellMITC4Thermal   94  122 123 98  97  2
element ShellMITC4Thermal   95  123 124 99  98  2
element ShellMITC4Thermal   96  124 125 100 99  2

element ShellMITC4Thermal   97  51  52  152 151 3
element ShellMITC4Thermal   98  52  53  153 152 3
element ShellMITC4Thermal   99  53  54  154 153 3
element ShellMITC4Thermal   100 54  55  155 154 3
element ShellMITC4Thermal   101 55  56  156 155 3
element ShellMITC4Thermal   102 56  57  157 156 3
element ShellMITC4Thermal   103 57  58  158 157 3
element ShellMITC4Thermal   104 58  59  159 158 3
element ShellMITC4Thermal   105 59  60  160 159 3
element ShellMITC4Thermal   106 60  61  161 160 3
element ShellMITC4Thermal   107 61  62  162 161 3
element ShellMITC4Thermal   108 62  63  163 162 3
element ShellMITC4Thermal   109 63  64  164 163 3
element ShellMITC4Thermal   110 64  65  165 164 3
element ShellMITC4Thermal   111 65  66  166 165 3
element ShellMITC4Thermal   112 66  67  167 166 3
element ShellMITC4Thermal   113 67  68  168 167 3
element ShellMITC4Thermal   114 68  69  169 168 3
element ShellMITC4Thermal   115 69  70  170 169 3
element ShellMITC4Thermal   116 70  71  171 170 3
element ShellMITC4Thermal   117 71  72  172 171 3
element ShellMITC4Thermal   118 72  73  173 172 3
element ShellMITC4Thermal   119 73  74  174 173 3
element ShellMITC4Thermal   120 74  75  175 174 3
element ShellMITC4Thermal   121 126 127 52  51  3
element ShellMITC4Thermal   122 127 128 53  52  3
element ShellMITC4Thermal   123 128 129 54  53  3
element ShellMITC4Thermal   124 129 130 55  54  3
element ShellMITC4Thermal   125 130 131 56  55  3
element ShellMITC4Thermal   126 131 132 57  56  3
element ShellMITC4Thermal   127 132 133 58  57  3
element ShellMITC4Thermal   128 133 134 59  58  3
element ShellMITC4Thermal   129 134 135 60  59  3
element ShellMITC4Thermal   130 135 136 61  60  3
element ShellMITC4Thermal   131 136 137 62  61  3
element ShellMITC4Thermal   132 137 138 63  62  3
element ShellMITC4Thermal   133 138 139 64  63  3
element ShellMITC4Thermal   134 139 140 65  64  3
element ShellMITC4Thermal   135 140 141 66  65  3
element ShellMITC4Thermal   136 141 142 67  66  3
element ShellMITC4Thermal   137 142 143 68  67  3
element ShellMITC4Thermal   138 143 144 69  68  3
element ShellMITC4Thermal   139 144 145 70  69  3
element ShellMITC4Thermal   140 145 146 71  70  3
element ShellMITC4Thermal   141 146 147 72  71  3
element ShellMITC4Thermal   142 147 148 73  72  3
element ShellMITC4Thermal   143 148 149 74  73  3
element ShellMITC4Thermal   144 149 150 75  74  3
element ShellMITC4Thermal   145 101 102 202 201 3
element ShellMITC4Thermal   146 102 103 203 202 3
element ShellMITC4Thermal   147 103 104 204 203 3
element ShellMITC4Thermal   148 104 105 205 204 3
element ShellMITC4Thermal   149 105 106 206 205 3
element ShellMITC4Thermal   150 106 107 207 206 3
element ShellMITC4Thermal   151 107 108 208 207 3
element ShellMITC4Thermal   152 108 109 209 208 3
element ShellMITC4Thermal   153 109 110 210 209 3
element ShellMITC4Thermal   154 110 111 211 210 3
element ShellMITC4Thermal   155 111 112 212 211 3
element ShellMITC4Thermal   156 112 113 213 212 3
element ShellMITC4Thermal   157 113 114 214 213 3
element ShellMITC4Thermal   158 114 115 215 214 3
element ShellMITC4Thermal   159 115 116 216 215 3
element ShellMITC4Thermal   160 116 117 217 216 3
element ShellMITC4Thermal   161 117 118 218 217 3
element ShellMITC4Thermal   162 118 119 219 218 3
element ShellMITC4Thermal   163 119 120 220 219 3
element ShellMITC4Thermal   164 120 121 221 220 3
element ShellMITC4Thermal   165 121 122 222 221 3
element ShellMITC4Thermal   166 122 123 223 222 3
element ShellMITC4Thermal   167 123 124 224 223 3
element ShellMITC4Thermal   168 124 125 225 224 3
element ShellMITC4Thermal   169 176 177 102 101 3
element ShellMITC4Thermal   170 177 178 103 102 3
element ShellMITC4Thermal   171 178 179 104 103 3
element ShellMITC4Thermal   172 179 180 105 104 3
element ShellMITC4Thermal   173 180 181 106 105 3
element ShellMITC4Thermal   174 181 182 107 106 3
element ShellMITC4Thermal   175 182 183 108 107 3
element ShellMITC4Thermal   176 183 184 109 108 3
element ShellMITC4Thermal   177 184 185 110 109 3
element ShellMITC4Thermal   178 185 186 111 110 3
element ShellMITC4Thermal   179 186 187 112 111 3
element ShellMITC4Thermal   180 187 188 113 112 3
element ShellMITC4Thermal   181 188 189 114 113 3
element ShellMITC4Thermal   182 189 190 115 114 3
element ShellMITC4Thermal   183 190 191 116 115 3
element ShellMITC4Thermal   184 191 192 117 116 3
element ShellMITC4Thermal   185 192 193 118 117 3
element ShellMITC4Thermal   186 193 194 119 118 3
element ShellMITC4Thermal   187 194 195 120 119 3
element ShellMITC4Thermal   188 195 196 121 120 3
element ShellMITC4Thermal   189 196 197 122 121 3
element ShellMITC4Thermal   190 197 198 123 122 3
element ShellMITC4Thermal   191 198 199 124 123 3
element ShellMITC4Thermal   192 199 200 125 124 3

# add on 0604
#equalDOF 25 50  1 2 3 4 5 6 
#equalDOF 25 75  1 2 3 4 5 6 
#equalDOF 25 100 1 2 3 4 5 6 
#equalDOF 25 125 1 2 3 4 5 6 
#equalDOF 25 150 1 2 3 4 5 6 
#equalDOF 25 175 1 2 3 4 5 6 
#equalDOF 25 200 1 2 3 4 5 6 
#equalDOF 25 225 1 2 3 4 5 6                       

element  adapter 1000000  -node  25 -dof 3  -stif  3E+09  44000

# Define DISPLAY -------------------------------------------------------------
# Comment 0419
#set  xPixels 1200;  # height of graphical window in pixels
#set  yPixels 800;   # height of graphical window in pixels
#set  xLoc1 10;  # horizontal location of graphical window (0=upper left-most corner)
#set  yLoc1 10;  # vertical location of graphical window (0=upper left-most corner)
#set dAmp 10;    # scaling factor for viewing deformed shape, it depends on the dimensions of the model
#DisplayModel3D NodeNumbers $dAmp $xLoc1 $yLoc1  $xPixels $yPixels
#
#recorder Element -file ShellData/EleForceSec2Tempm.out -time -ele 153   material 2 fiber 2 TempAndElong;
#recorder Element -file ShellData/EleForceSec2stressm.out -time -ele 10  material 2 fiber 2 stress;  
#
#recorder Element -file ShellData/EleForceSec2stress1m.out -time -ele 1  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress20m.out -time -ele 20  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress22m.out -time -ele 22  material 2 fiber 2 stress;
#
#recorder Element -file ShellData/EleForceSec2stress81m.out -time -ele 81  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress90m.out -time -ele 90  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress121m.out -time -ele 122  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress130m.out -time -ele 130  material 2 fiber 2 stress;
#
#recorder Element -file ShellData/EleForceSec2strainm.out -time -ele 10  material 2 fiber 2 strain;

recorder Node -file BaseNode1.out   -time -node 1    -dof 1 2 3 4 5 6  disp
recorder Node -file BaseNode101.out -time -node 101  -dof 1 2 3 4 5 6  disp
recorder Node -file MidNode25.out   -time -node 25   -dof 1 2 3 4 5 6  disp
recorder Node -file MidNode125.out  -time -node 125  -dof 1 2 3 4 5 6  disp
#recorder Node -file DFreeSlabyT16m.out -time -nodeRange 126  150 -dof 2 disp;
#recorder Node -file DFreeSlabyT163m.out -time -nodeRange 176  200 -dof 2 disp;
##
#recorder Node -file DFreeSlabyTwebottom.out -time -nodeRange 101 125 -dof 3 disp;
#recorder Node -file DFreeSlabyTwebtop.out -time -nodeRange 76 100 -dof 3 disp;
#recorder Node -file DFreeSlabyT13m.out -time -nodeRange 1 25 -dof 3 disp;
#
#recorder Node -file DFreeSlabyT14m.out -time -nodeRange 26  50 -dof 3 disp;
#
#recorder Node -file DFreeSlabyT15m.out -time -nodeRange 51 75 -dof 3 disp;
#set  xPixels 1200; # height of graphical window in pixels
#set  yPixels 800; # height of graphical window in pixels
#set  xLoc1 10; # horizontal location of graphical window (0=upper left-most corner)
#set  yLoc1 10; # vertical location of graphical window (0=upper left-most corner)
#set ViewScale 1.0e-5; # scaling factor for viewing deformed shape, it depends on the dimensions of the model

puts "nodal coordinates defined"

# Comment on 0520
# set UDLP 43;
set UDLP 15687.0;
# set UDLP 0

pattern Plain 1 Linear {
   
    

load    25  0   0 -$UDLP  0   0   0     ;

  
}
constraints Plain;
numberer Plain;
system SparseSYM;
test NormDispIncr 1e-1  10 1;
algorithm Newton;
integrator LoadControl 0.001; 
analysis Static; 
# 0524 modified           
#analyze 10;
analyze 1000 0.01
loadConst -time 0.0

##pattern Plain 2 Linear {
#
#    #eleLoad -range 1 96 -type -shellThermal 700 [expr -0.0032] 700 [expr 0.0032];
#    #eleLoad -range 97  144 -type -shellThermal 650 [expr -0.0044] 650 [expr 0.0044];
#    #eleLoad -range 145  192 -type -shellThermal 800 [expr -0.0044] 800 [expr 0.0044];
#    #eleLoad -range 193  288 -type -shellThermal 450 [expr -0.03] 20 [expr 0.03];
##};
#pattern Plain 3 Linear {
#
#for {set level 1} {$level <=96} {incr level 1} { 
#set eleID $level
#eleLoad -ele $eleID -type -shellThermal -source "anjbfw.out"  -0.006   0.006;
#
#}
#
#for {set level 97} {$level <=192} {incr level 1} { 
#set eleID $level
#eleLoad -ele $eleID -type -shellThermal -source "anjbfw.out"  -0.008   0.008;
#
#}
#
#}
#
#
## Start of analysis generation
## ------------------------------
## create the system of equations
#system SparseSYM
#
## create the DOF numberer
#numberer Plain
#
## create the constraint handler
#constraints Transformation
#
## create the convergence test
#test NormDispIncr 1e-3 50 1;
#
##test NormUnbalance 1.0e-12 25
##test EnergyIncr 1.0e-12 25
#
## create the integration scheme
#integrator LoadControl 50
#
## create the solution algorithm
#algorithm KrylovNewton
#
## create the analysis object 
#analysis Static
## ------------------------------
#
#
## ------------------------------
## Finally perform the analysis
## ------------------------------
#analyze 80
## --------------------------------
## End of analysis
## --------------------------------








