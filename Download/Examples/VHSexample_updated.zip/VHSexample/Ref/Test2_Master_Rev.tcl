wipe;
#units are mm, N, MPa, ton, and C



# Column coordinates
set CD23x 0
set CD23y 0
set C1x -4500
set C1y -10500
set C2x -4500
set C2y -4500
set C23x -4500
set C23y 0
set C3x -4500
set C3y 4500
set C4x -4500
set C4y 10500

set B1x -13500
set B1y -10500
set B2x -13500
set B2y -4500
set B3x -13500
set B3y 4500
set B4x -13500
set B4y 10500

set AB23x -18450
set AB23y -2400
set AB3x -18450
set AB3y 4500

set A1x -22500
set A1y -10500
set A2x -22500
set A2y -4500
set A23x -22500
set A23y 0
set A3x -22500
set A3y 4500
set A4x -22500
set A4y 10500


set zlimi -4000.0
set zlimf 4000.0

# Depth
set h_rib 55.5
set h_slab 75.0
set h_UB356 355.0
set h_UB305 303.4
set h_UB610 602.6 
set h_UB254 251.4

# Mesh
set elemL 300
set colL 500
set xSpan1 4500
set xSpan2 9000
set ySpan1 6000
set ySpan2 9000



# Model builder
model BasicBuilder -ndm 3 -ndf 6;
source DisplayPlane.tcl
source DisplayModel2D.tcl
source DisplayModel3D.tcl
#nodes####################################################################################################################

# Load OpenFresco package
# -----------------------
# (make sure all dlls are in the same folder as openSees.exe)
loadPackage OpenFresco



# Execute
source sections.tcl
puts "loaded 'sections' correctly"
source nodes.tcl
puts "loaded 'nodes' correctly"
source constraints.tcl
puts "loaded 'constraints' correctly"
# Edit on 0520
expControlPoint 1  -node 2817 3 disp 
expControlPoint 2  -node 2817 3 disp 3 force



#OpenFresco Classes
expControl SimFEAdapter 1 "127.0.0.1" 44000  -trialCP 1 -outCP 2

# Define experimental setup
# -------------------------
# expSetup NoTransformation $tag <–control $ctrlTag> –dir $dirs … -sizeTrialOut t o <–ctrlDispFact $f> ...
# Modified on 0515 to express the direction transformation
# expSetup NoTransformation 1 -control 1 -dir 2 1 4  -sizeTrialOut 6 6 
expSetup NoTransformation 1 -control 1 -dir 3  -sizeTrialOut 6 6 

# Define experimental site
# ------------------------
# expSite LocalSite $tag $setupTag
expSite LocalSite 1 1
recorder Node -file BaseNode1.out   -time -node 1    -dof 1 2 3 4 5 6  disp
source elements.tcl
# edited on 0527
# expElement beamColumn 200 2801 2817 44 -site 1 -initStif  1213 0 0 0 11.2 -302.4 0 -302.4 10886.4
expElement beamColumn 200 2801 2817 44 -site 1 -initStif 1260000    0   0   0   0   0   -1260000    0   0   0   0   0\
0   6112.5  0   0   0   12225000    0   -6112.5 0   0   0   12225000\
0   0   19087.5 0   -38175000   0   0   0   -19087.5    0   -38175000   0\
0   0   0   142200000   0   0   0   0   0   -142200000  0   0\
0   0   -38175000   0   1.018E+11   0   0   0   38175000    0   1.018E+11   0\
0   12225000    0   0   0   32600000000 0   -12225000   0   0   0   32600000000\
-1260000    0   0   0   0   0   1260000 0   0   0   0   0\
0   -6112.5 0   0   0   -12225000   0   6112.5  0   0   0   -12225000\
0   0   -19087.5    0   38175000    0   0   0   19087.5 0   38175000    0\
0   0   0   -142200000  0   0   0   0   0   142200000   0   0\
0   0   -38175000   0   1.018E+11   0   0   0   38175000    0   1.018E+11   0\
0   12225000    0   0   0   32600000000 0   -12225000   0   0   0   32600000000

puts "loaded 'elements' correctly"
source loads.tcl






