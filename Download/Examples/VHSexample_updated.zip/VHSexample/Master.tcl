## Revision Log

## Revised on 08/18
# To tackle the initial stiffness issues.


wipe;
#  units are mm, N, MPa, ton, and C
#  0715
#  Column coordinates
set CD23x 0
set CD23y 0
set C1x -4500
set C1y -10500
set C2x -4500
set C2y -4500
set C23x -4500
set C23y 0
set C3x -4500
set C3y 4500
set C4x -4500
set C4y 10500

set B1x -13500
set B1y -10500
set B2x -13500
set B2y -4500
set B3x -13500
set B3y 4500
set B4x -13500
set B4y 10500

set AB23x -18450
set AB23y -2400
set AB3x -18450
set AB3y 4500

set A1x -22500
set A1y -10500
set A2x -22500
set A2y -4500
set A23x -22500
set A23y 0
set A3x -22500
set A3y 4500
set A4x -22500
set A4y 10500


set zlimi -4000.0
set zlimf 4000.0

# Depth
set h_rib 55.5
set h_slab 75.0
set h_UB356 355.0
set h_UB305 303.4
set h_UB610 602.6 
set h_UB254 251.4

# Mesh
set elemL 300
set colL 500
set xSpan1 4500
set xSpan2 9000
set ySpan1 6000
set ySpan2 9000



# Model builder
model BasicBuilder -ndm 3 -ndf 6;
source DisplayPlane.tcl
source DisplayModel2D.tcl
source DisplayModel3D.tcl
#nodes####################################################################################################################
logFile "Hybrid20210818_master.log"
# Load OpenFresco package
# -----------------------
# (make sure all dlls are in the same folder as openSees.exe)
loadPackage OpenFresco

# Execute
source sections.tcl
puts "loaded 'sections' correctly"
source nodes.tcl
puts "loaded 'nodes' correctly"
source constraints.tcl
puts "loaded 'constraints' correctly"

## Define the control point (Column B2)
#expControlPoint 1  -node 2817 3 disp 
#expControlPoint 2  -node 2817 3 disp 3 force

expControlPoint 1 -node 2817 1 disp 2 disp 3 disp
expControlPoint 2 -node 2817 1 disp 2 disp 3 disp 1 force 2 force 3 force

expControlPoint 3 -node 2917 1 disp 2 disp 3 disp
expControlPoint 4 -node 2917 1 disp 2 disp 3 disp 1 force 2 force 3 force

#expControlPoint 1 -node 2817 1 disp
#expControlPoint 2 -node 2817 1 disp 1 force

## Define the test control method
#expControl SimFEAdapter 1 "127.0.0.1" 44000  -trialCP 1 -outCP 2
expControl SimFEAdapter 1 "127.0.0.1" 44000 -trialCP 1 -outCP 2
expControl SimFEAdapter 2 "127.0.0.1" 43000 -trialCP 3 -outCP 4
#expControl SimFEAdapter 2 "127.0.0.1" 44000 -trialCP 1 -outCP 2
## Define the transformation
expSetup NoTransformation 1 -control 1 -dir 2 4 1  -sizeTrialOut 6 6
expSetup NoTransformation 2 -control 2 -dir 2 4 1  -sizeTrialOut 6 6
#expSetup NoTransformation 1 -control 1 -dir 1  -sizeTrialOut 6 6
#expSetup NoTransformation 1 -control 1 -dir 1 2 3  -sizeTrialOut 6 6
#expSetup NoTransformation 1 -control 1 -dir 2 4 1 5 3 6  -sizeTrialOut 6 6

## Define the Test site
expSite LocalSite 1 1
expSite LocalSite 2 2
## End of OpenFresco

source elements.tcl
#expElement beamColumn 200 2801 2817 44 -site 1 -initStif 1260000    0   0   0   0   0   -1260000    0   0   0   0   0\
#0   6112.5  0   0   0   12225000    0   -6112.5 0   0   0   12225000\
#0   0   19087.5 0   -38175000   0   0   0   -19087.5    0   -38175000   0\
#0   0   0   142200000   0   0   0   0   0   -142200000  0   0\
#0   0   -38175000   0   1.018E+11   0   0   0   38175000    0   1.018E+11   0\
#0   12225000    0   0   0   32600000000 0   -12225000   0   0   0   32600000000\
#-1260000    0   0   0   0   0   1260000 0   0   0   0   0\
#0   -6112.5 0   0   0   -12225000   0   6112.5  0   0   0   -12225000\
#0   0   -19087.5    0   38175000    0   0   0   19087.5 0   38175000    0\
#0   0   0   -142200000  0   0   0   0   0   142200000   0   0\
#0   0   -38175000   0   1.018E+11   0   0   0   38175000    0   1.018E+11   0\
#0   12225000    0   0   0   32600000000 0   -12225000   0   0   0   32600000000
# 07/31 previous stiffness
#expElement beamColumn 200 2801 2817 44 -site 1 -initStif\
#8.7e6  0     0    0      0  0\
#0      100   0    0      0  0\
#0      0     0    0      0  0\
#0      0     0    220    0  0\
#0      0     0    0      0  0\
#0      0     0    0      0  0\

# 07/31 Revised stiffness
## A=17000 E=2.1e5 L=4000
expElement beamColumn 200000 2801 2817 44 -site 1 -initStif\
9.1e5  0     0        0      0  0\
0      1054  0        0      0  0\
0      0     0        0      0  0\
0      0     0        3200    0  0\
0      0     0        0      0  0\
0      0     0        0      0  0\

expElement beamColumn 200001 2901 2917 44 -site 2 -initStif\
9.1e5  0     0        0      0  0\
0      1054  0        0      0  0\
0      0     0        0      0  0\
0      0     0        3200    0  0\
0      0     0        0      0  0\
0      0     0        0      0  0\

puts "loaded 'elements' correctly"
source loads.tcl



