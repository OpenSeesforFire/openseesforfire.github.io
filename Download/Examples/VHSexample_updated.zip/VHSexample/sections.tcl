## Revised on 21/07/29
## Chou Jin section and updated fiber
#Material props
set fpc -35.0
set epsc0 -0.0025
set fpcu [expr $fpc*0.05];
set epsU -0.02
set lambda 0.1
set ft 3.5
set epstu 0.002
set Ets [expr $ft/$epstu];
set Ec [expr 1.5*abs($fpc/$epsc0)];#[expr sqrt(abs($fpc))*4700.0]; #lwc from ACI 
set Gc [expr $Ec/(2.0*(1+0.2))]; #N/mm2
# Beam steels
set E 2.1e5;
set G [expr $E/(2.0*(1+0.3))]; #N/mm2
# GJ; N/rad
uniaxialMaterial Steel01Thermal 1 355.0 $E 0.01;                                # S355 - range of 371 to 413 MPa; had 400 at first.
uniaxialMaterial Steel01Thermal 2 275.0 $E 0.01;                                # S275 - range of 291 - 318 MPa; had 300 at first.

# Slab concrete
set gt [expr abs($ft/$Ec*$ft*3.5)];
set gc [expr abs($fpc/$Ec*$fpc*6)];
nDMaterial   CDPPlaneStressThermal 5 $Ec 0.2 $ft [expr abs($fpc)] $gt $gc;
nDMaterial   PlateFromPlaneStressThermal    6   5   10.0e3;                         #what is this 1000 value at the end??

# Slab steel
uniaxialMaterial Steel01Thermal 7 460.0 $E 0.01;                                    # Rebar steel; had 485 at first
nDMaterial PlateRebarThermal 77 7 0;
nDMaterial PlateRebarThermal 8 7 90;

uniaxialMaterial Steel01Thermal 4 350.0 $E 0.01;                                    # Decking steel - minimum of 350 MPa
nDMaterial PlateRebarThermal 9 4 0; # Decking steel - minimum of 350 MPa                       
nDMaterial PlateRebarThermal 10 4 90;#(QJ-web decking for rib)

nDMaterial  J2PlaneStressThermal 11 21 $E 0.3 350.0 420 0.02 0; #(QJ-decking)
nDMaterial  PlateFromPlaneStressThermal    12   11   20e3; #(QJ-decking)     

# Slab section
set rebarT 0.141; #rebar layer thickness
set deckingT 0.9; #thickness of steel deck
set concT 75.0;
#set slabT [expr $concT + $rebarT*2 + $deckingT]
set halfT [expr $concT/2.0]
set SecTag 1
set slab $SecTag 
#section LayeredShell         $sectionTag $nLayers $matTag1 $thickness1...$matTagn $thicknessn
#section LayeredShellThermal   $slab          11       9 $deckingT   6 [expr 10.0 - $deckingT]    6 10.0   8 $rebarT  77 $rebarT   6 [expr 10.0 - 2*$rebarT]   6 10.0    6 10.0   6 10.0   6 10.0 6 5.0; 
section LayeredShellThermal   $slab           11       12 $deckingT   6 [expr 10.0 - $deckingT]   6 10.0   77 $rebarT 8 $rebarT   6 [expr 10.0 - 2*$rebarT]   6 10.0    6 10.0   6 10.0   6 10.0 6 5.0; #(QJ)

#set concT 130.0;
set ribT 55.0
#set deckingT 1.0;
#set slabT2 [expr $concT + $rebarT*2 + $deckingT]
#set halfT2 [expr $slabT2/2.0]
set SecTag 2
set rib $SecTag 
#section LayeredShell         $sectionTag $nLayers $matTag1 $thickness1...$matTagn $thicknessn
#section LayeredShellThermal   $rib       16    -offset 27.5   9 $deckingT   6 [expr 10.0 - $deckingT]      6 10.0      6 10.0      6 10.0      6 10.0    6 10.0    6 10.0   8 $rebarT  77 $rebarT   6 [expr 10.0 - 2*$rebarT]   6 10.0    6 10.0   6 10.0   6 10.0   6 5.0
section  LayeredShellThermal   $rib  -Rib  $concT $ribT  90.0  21   12 0.653 -92.05  6 6.84 -87.05  9 0.1456 -82.5  6 7.99 -77.5  10 0.1456 -72.5  6 8.5 -67.5  10 0.1456 -62.5  6 9 -57.5  10 0.1456 -52.5  6 9.5 -47.5  6 5 -40  6 10 -32.5  6 10 -22.5  77 $rebarT -17.429  8 $rebarT -17.287  6 10 -12.216  6 10 -2.216 6 10 7.784  6 10 17.784  6 10 27.784  6 5 35.142 


#################################
#  y is the vertical local axis #
#  where fibers are for bending #
#  and z is the lateral one for #
#  torsion. specify both.       #
#################################

## Sections 
## UB356x171x51
#set matTag 1; # S355 
#set SecTag 3
#set UB356 $SecTag 
#set J [expr 23.8e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG { 
##fiber       $yLoc   $zLoc          $A            $matTag
#fiber   175.5833333     42.875  328.7083333 $matTag
#fiber   171.75          42.875  328.7083333 $matTag
#fiber   167.9166667     42.875  328.7083333 $matTag
#fiber   175.5833333     -42.875 328.7083333 $matTag
#fiber   171.75          -42.875 328.7083333 $matTag
#fiber   167.9166667     -42.875 328.7083333 $matTag
#fiber   138.3333333     0.0     409.4666667 $matTag
#fiber   83              0.0     409.4666667 $matTag
#fiber   27.66666667     0.0     409.4666667 $matTag
#fiber   -27.66666667    0.0     409.4666667 $matTag
#fiber   -83             0.0     409.4666667 $matTag
#fiber   -138.3333333    0.0     409.4666667 $matTag
#fiber   -167.9166667    -42.875 328.7083333 $matTag
#fiber   -171.75         -42.875 328.7083333 $matTag
#fiber   -175.5833333    -42.875 328.7083333 $matTag
#fiber   -167.9166667    42.875  328.7083333 $matTag
#fiber   -171.75         42.875  328.7083333 $matTag
#fiber   -175.5833333    42.875  328.7083333 $matTag
#};
#
## UB305x165x40
#set matTag 2
#set SecTag 4
#set UB305 $SecTag
#set J [expr 14.7e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG { 
##fiber       $yLoc   $zLoc          $A                 $matTag
#fiber   150.0   41.25   280.5   $matTag
#fiber   146.6   41.25   280.5   $matTag
#fiber   143.2   41.25   280.5   $matTag
#fiber   150.0   -41.25  280.5   $matTag
#fiber   146.6   -41.25  280.5   $matTag
#fiber   143.2   -41.25  280.5   $matTag
#fiber   117.92  0.0     283.0   $matTag
#fiber   70.75   0.0     283.0   $matTag
#fiber   23.58   0.0     283.0   $matTag
#fiber   -23.58  0.0     283.0   $matTag
#fiber   -70.75  0.0     283.0   $matTag
#fiber   -117.92 0.0     283.0   $matTag
#fiber   -143.2  -41.25  280.5   $matTag
#fiber   -146.6  -41.25  280.5   $matTag
#fiber   -150    -41.25  280.5   $matTag
#fiber   -143.2  41.25   280.5   $matTag
#fiber   -146.6  41.25   280.5   $matTag
#fiber   -150    41.25   280.5   $matTag
#}
#
## UB610x229x101
#set matTag 2
#set SecTag 5
#set UB610 $SecTag
#set J [expr 77.0e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG { 
##fiber       $yLoc   $zLoc          $A             $matTag
#fiber   298.83  56.9    561.41  $matTag
#fiber   293.90  56.9    561.41  $matTag
#fiber   288.97  56.9    561.41  $matTag
#fiber   298.83  -56.9   561.41  $matTag
#fiber   293.90  -56.9   561.41  $matTag
#fiber   288.97  -56.9   561.41  $matTag
#fiber   238.75  0.0     1002.75 $matTag
#fiber   143.25  0.0     1002.75 $matTag
#fiber   47.75   0.0     1002.75 $matTag
#fiber   -47.75  0.0     1002.75 $matTag
#fiber   -143.25 0.0     1002.75 $matTag
#fiber   -238.75 0.0     1002.75 $matTag
#fiber   -288.97 -56.9   561.41  $matTag
#fiber   -293.90 -56.9   561.41  $matTag
#fiber   -298.83 -56.9   561.41  $matTag
#fiber   -288.97 56.9    561.41  $matTag
#fiber   -293.90 56.9    561.41  $matTag
#fiber   -298.83 56.9    561.41  $matTag
#}
#
## UB254x146x31
#set MatTag 2 
#set SecTag 6
#set UB254 $SecTag
#set J [expr 8.55e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG {
##fiber       $yLoc   $zLoc          $A  $matTag
# fiber 124.26670000     -36.525 209.41        $MatTag
# fiber 121.40000000     -36.525 209.41        $MatTag
# fiber 118.53330000     -36.525 209.41        $MatTag
# fiber 124.26670000     36.525 209.41         $MatTag
# fiber 121.40000000     36.525 209.41         $MatTag
# fiber 118.53330000     36.525 209.41         $MatTag
# fiber 87.82500000     0.0 351.30000000  $MatTag
# fiber 29.27500000     0.0 351.30000000  $MatTag
# fiber -29.27500000     0.0 351.30000000  $MatTag
# fiber -87.82500000     0.0 351.30000000  $MatTag
# fiber -118.53330000     -36.525 209.41       $MatTag
# fiber -121.40000000     -36.525 209.41       $MatTag
# fiber -124.26670000     -36.525 209.41       $MatTag
# fiber -118.53330000     36.525 209.41        $MatTag
# fiber -121.40000000     36.525 209.41        $MatTag
# fiber -124.26670000     36.525 209.41        $MatTag
#}
#
## UC305x305x137
#set MatTag 1 
#set SecTag 7
#set UC305 $SecTag
#set J [expr 249.0e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG { 
##fiber       $yLoc      $zLoc      $A       $matTag
# fiber 156.63330000     -77.3   1118.27     $MatTag
# fiber 149.40000000     -77.3   1118.27     $MatTag
# fiber 142.16670000     -77.3   1118.27     $MatTag
# fiber 156.63330000      77.3   1118.27     $MatTag
# fiber 149.40000000      77.3   1118.27     $MatTag
# fiber 142.16670000      77.3   1118.27     $MatTag
# fiber 103.91250000      0.0    955.995     $MatTag
# fiber 34.63750000       0.0    955.995     $MatTag
# fiber -34.63750000      0.0    955.995     $MatTag
# fiber -103.91250000     0.0    955.995     $MatTag
# fiber -142.16670000     77.3   1118.27     $MatTag
# fiber -149.40000000     77.3   1118.27     $MatTag
# fiber -156.63330000     77.3   1118.27     $MatTag
#  fiber -142.16670000    -77.3  1118.27     $MatTag
# fiber -149.40000000     -77.3  1118.27     $MatTag
# fiber -156.63330000     -77.3  1118.27     $MatTag
#}
#
## COLUMN SECTION
## UC305x305x198
#set MatTag 1 
#set SecTag 8
#set UC305x198 $SecTag
#set J [expr 734.0e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG {
##fiber       $yLoc   $zLoc          $A  $matTag
# fiber 164.71670000     -78.6250 1645.9  $MatTag
# fiber 154.25000000     -78.6250 1645.9  $MatTag
# fiber 143.78330000     -78.6250 1645.9  $MatTag
# fiber 164.71670000     78.6250 1645.9  $MatTag
# fiber 154.25000000     78.6250 1645.9  $MatTag
# fiber 143.78330000     78.6250 1645.9  $MatTag
# fiber 103.91250000     0.0 1323.1525  $MatTag
# fiber 34.63750000     0.0 1323.1525  $MatTag
# fiber -34.63750000     0.0 1323.1525  $MatTag
# fiber -103.91250000     0.0 1323.1525  $MatTag
# fiber -143.78330000     78.6250 1645.9  $MatTag
# fiber -154.25000000     78.6250 1645.9  $MatTag
# fiber -164.71670000     78.6250 1645.9  $MatTag
# fiber -143.78330000     -78.6250 1645.9  $MatTag
# fiber -154.25000000     -78.6250 1645.9  $MatTag
# fiber -164.71670000     -78.6250 1645.9  $MatTag
#}
#
## UC254x254x89
#set MatTag 1 
#set SecTag 9
#set UC254 $SecTag
#set J [expr 102.0e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG { 
##fiber       $yLoc   $zLoc          $A  $matTag
# fiber 127.26670000     -64.075 739.0  $MatTag
# fiber 121.50000000     -64.075 739.0  $MatTag
# fiber 115.73330000     -64.075 739.0  $MatTag
# fiber 127.26670000     64.075 739.0  $MatTag
# fiber 121.50000000     64.075 739.0  $MatTag
# fiber 115.73330000     64.075 739.0  $MatTag
# fiber 84.63750000     0.0 581.17750000  $MatTag
# fiber 28.21250000     0.0 581.17750000  $MatTag
# fiber -28.21250000     0.0 581.17750000  $MatTag
# fiber -84.63750000     0.0 581.17750000  $MatTag
# fiber -115.73330000     64.075 739.0  $MatTag
# fiber -121.50000000     64.075 739.0  $MatTag
# fiber -127.26670000     64.075 739.0  $MatTag
# fiber -115.73330000     -64.075 739.0  $MatTag
# fiber -121.50000000     -64.075 739.0  $MatTag
# fiber -127.26670000     -64.075 739.0  $MatTag
#}
#
#################################
#  y is the vertical local axis #
#  where fibers are for bending #
#  and z is the lateral one for #
#  torsion. specify both.       #
#################################

# Sections 
# UB356x171x51
# revised on 0720
set matTag 1; # S355 
set SecTag 3
set UB356 $SecTag 
set J [expr 23.8e4]
set JG [expr $J*$G]
section fiberSecThermal $SecTag -GJ $JG { 
#fiber       $yLoc   $zLoc          $A            $matTag
fiber   172.05          71.46  328.7083333 $matTag
fiber   172.05          42.88  328.7083333 $matTag
fiber   172.05          14.30  328.7083333 $matTag
fiber   172.05          -14.30 328.7083333 $matTag
fiber   172.05          -42.88 328.7083333 $matTag
fiber   172.05          -71.46 328.7083333 $matTag
fiber   138.3333333     0.0     409.4666667 $matTag
fiber   83              0.0     409.4666667 $matTag
fiber   27.66666667     0.0     409.4666667 $matTag
fiber   -27.66666667    0.0     409.4666667 $matTag
fiber   -83             0.0     409.4666667 $matTag
fiber   -138.3333333    0.0     409.4666667 $matTag
fiber   -172.05         71.46   328.7083333 $matTag
fiber   -172.05         42.88   328.7083333 $matTag
fiber   -172.05         14.30   328.7083333 $matTag
fiber   -172.05         -14.30  328.7083333 $matTag
fiber   -172.05         -42.88  328.7083333 $matTag
fiber   -172.05         -71.46  328.7083333 $matTag
};

# UB305x165x40
# revised on 0720
set matTag 2
set SecTag 4
set UB305 $SecTag
set J [expr 14.7e4]
set JG [expr $J*$G]
section fiberSecThermal $SecTag -GJ $JG { 
#fiber       $yLoc   $zLoc          $A                 $matTag
fiber   146.8   68.79   280.5   $matTag
fiber   146.8   41.27   280.5   $matTag
fiber   146.8   13.75   280.5   $matTag
fiber   146.8   -13.75  280.5   $matTag
fiber   146.8   -41.27  280.5   $matTag
fiber   146.8   -68.79  280.5   $matTag
fiber   117.92  0.0     283.0   $matTag
fiber   70.75   0.0     283.0   $matTag
fiber   23.58   0.0     283.0   $matTag
fiber   -23.58  0.0     283.0   $matTag
fiber   -70.75  0.0     283.0   $matTag
fiber   -117.92 0.0     283.0   $matTag
fiber   -146.8  68.79   280.5   $matTag
fiber   -146.8  41.27   280.5   $matTag
fiber   -146.8  13.75   280.5   $matTag
fiber   -146.8  -13.75   280.5   $matTag
fiber   -146.8  -41.27   280.5   $matTag
fiber   -146.8  -68.79   280.5   $matTag
}

# UB610x229x101
# revised on 0720
set matTag 2
set SecTag 5
set UB610 $SecTag
set J [expr 77.0e4]
set JG [expr $J*$G]
section fiberSecThermal $SecTag -GJ $JG { 
#fiber       $yLoc   $zLoc          $A             $matTag
fiber   293.70   94.83    561.41  $matTag
fiber   293.70   56.90    561.41  $matTag
fiber   293.70   18.97    561.41  $matTag
fiber   293.70  -18.97    561.41  $matTag
fiber   293.70  -56.90    561.41  $matTag
fiber   293.70  -94.83    561.41  $matTag
fiber   238.75     0.0    1002.75 $matTag
fiber   143.25     0.0    1002.75 $matTag
fiber    47.75     0.0    1002.75 $matTag
fiber   -47.75     0.0    1002.75 $matTag
fiber   -143.25    0.0    1002.75 $matTag
fiber   -238.75    0.0    1002.75 $matTag
fiber   -293.70  94.83    561.41  $matTag
fiber   -293.70  56.90    561.41  $matTag
fiber   -293.70  18.97    561.41  $matTag
fiber   -293.70 -18.97    561.41  $matTag
fiber   -293.70 -56.90    561.41  $matTag
fiber   -293.70 -94.83    561.41  $matTag
}

## UB254x146x31
#set MatTag 2 
#set SecTag 6
#set UB254 $SecTag
#set J [expr 8.55e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG {
##fiber       $yLoc   $zLoc          $A  $matTag
# fiber 124.26670000     -36.525 209.41        $MatTag
# fiber 121.40000000     -36.525 209.41        $MatTag
# fiber 118.53330000     -36.525 209.41        $MatTag
# fiber 124.26670000     36.525 209.41         $MatTag
# fiber 121.40000000     36.525 209.41         $MatTag
# fiber 118.53330000     36.525 209.41         $MatTag
# fiber 87.82500000     0.0 351.30000000  $MatTag
# fiber 29.27500000     0.0 351.30000000  $MatTag
# fiber -29.27500000     0.0 351.30000000  $MatTag
# fiber -87.82500000     0.0 351.30000000  $MatTag
# fiber -118.53330000     -36.525 209.41       $MatTag
# fiber -121.40000000     -36.525 209.41       $MatTag
# fiber -124.26670000     -36.525 209.41       $MatTag
# fiber -118.53330000     36.525 209.41        $MatTag
# fiber -121.40000000     36.525 209.41        $MatTag
# fiber -124.26670000     36.525 209.41        $MatTag
#}

# UC305x305x137
set MatTag 1 
set SecTag 7
set UC305 $SecTag
set J [expr 249.0e4]
set JG [expr $J*$G]
section fiberSecThermal $SecTag -GJ $JG { 
#fiber       $yLoc         $zLoc      $A       $matTag
 fiber 149.40000000       128.625  1118.27     $MatTag
 fiber 149.40000000       77.175   1118.27     $MatTag
 fiber 149.40000000       25.725   1118.27     $MatTag
 fiber 149.40000000      -25.725   1118.27     $MatTag
 fiber 149.40000000      -77.175   1118.27     $MatTag
 fiber 149.40000000     -128.625   1118.27     $MatTag
 fiber 103.91250000         0.0    955.995     $MatTag
 fiber 34.63750000          0.0    955.995     $MatTag
 fiber -34.63750000         0.0    955.995     $MatTag
 fiber -103.91250000        0.0    955.995     $MatTag
 fiber -149.40000000     128.625   1118.27     $MatTag
 fiber -149.40000000     77.175    1118.27     $MatTag
 fiber -149.40000000     25.725    1118.27     $MatTag
 fiber -149.40000000    -25.725    1118.27     $MatTag
 fiber -149.40000000     -77.175   1118.27     $MatTag
 fiber -149.40000000     -128.625  1118.27     $MatTag
}

# COLUMN SECTION
# UC305x305x198
#set MatTag 1 
#set SecTag 8
#set UC305x198 $SecTag
#set J [expr 734.0e4]
#set JG [expr $J*$G]
#section fiberSecThermal $SecTag -GJ $JG {
##fiber       $yLoc   $zLoc          $A  $matTag
# fiber 164.71670000     -78.6250 1645.9  $MatTag
# fiber 154.25000000     -78.6250 1645.9  $MatTag
# fiber 143.78330000     -78.6250 1645.9  $MatTag
# fiber 164.71670000     78.6250 1645.9  $MatTag
# fiber 154.25000000     78.6250 1645.9  $MatTag
# fiber 143.78330000     78.6250 1645.9  $MatTag
# fiber 103.91250000     0.0 1323.1525  $MatTag
# fiber 34.63750000     0.0 1323.1525  $MatTag
# fiber -34.63750000     0.0 1323.1525  $MatTag
# fiber -103.91250000     0.0 1323.1525  $MatTag
# fiber -143.78330000     78.6250 1645.9  $MatTag
# fiber -154.25000000     78.6250 1645.9  $MatTag
# fiber -164.71670000     78.6250 1645.9  $MatTag
# fiber -143.78330000     -78.6250 1645.9  $MatTag
# fiber -154.25000000     -78.6250 1645.9  $MatTag
# fiber -164.71670000     -78.6250 1645.9  $MatTag
#}

# UC254x254x89
# revised on 0720
set MatTag 1 
set SecTag 9
set UC254 $SecTag
set J [expr 102.0e4]
set JG [expr $J*$G]
section fiberSecThermal $SecTag -GJ $JG { 
#fiber       $yLoc   $zLoc          $A  $matTag
 fiber 121.55     106.625 739.0  $MatTag
 fiber 121.55      63.975 739.0  $MatTag
 fiber 121.55      21.325 739.0  $MatTag
 fiber 121.55     -21.325 739.0  $MatTag
 fiber 121.55     -63.975 739.0  $MatTag
 fiber 121.55    -106.625 739.0  $MatTag
 fiber 84.63750000     0.0 581.17750000  $MatTag
 fiber 28.21250000     0.0 581.17750000  $MatTag
 fiber -28.21250000     0.0 581.17750000  $MatTag
 fiber -84.63750000     0.0 581.17750000  $MatTag
 fiber -121.55     106.625 739.0  $MatTag
 fiber -121.55      63.975 739.0  $MatTag
 fiber -121.55      21.325 739.0  $MatTag
 fiber -121.55     -21.325 739.0  $MatTag
 fiber -121.55     -63.975 739.0  $MatTag
 fiber -121.55    -106.625 739.0  $MatTag
}

