fix 101 1 1 0 1 1 1
fix 201 1 1 0 1 1 1
fix 301 1 1 0 1 1 1
fix 401 1 1 0 1 1 1
fix 601 1 1 0 1 1 1
fix 701 1 1 0 1 1 1
fix 801 1 1 0 1 1 1
equalDOF 101 4001 1 2 3 4 5 6
equalDOF 201 4011 1 2 3 4 5 6
equalDOF 301 4021 1 2 3 4 5 6
equalDOF 401 4026 1 2 3 4 5 6
equalDOF 601 4051 1 2 3 4 5 6
equalDOF 701 4061 1 2 3 4 5 6
equalDOF 801 4071 1 2 3 4 5 6

# Column bases and tops
for {set i 1} {$i <= 17} {incr i 1} {
	fix [expr $i*100 + 2001] 1 1 1 1 1 1
	if {$i == 8 || $i == 9} {
		# Columns of interest - MUSTESIN
		fix [expr $i*100 + 2025] 1 1 0 1 1 1
	} else {
		fix [expr $i*100 + 2017] 1 1 0 1 1 1
	} 
}

# Column mastering slab's translation and rotation about z
equalDOF	2109	4036	1 2 3 6
equalDOF	2209	20001	1 2 3 6
equalDOF	2309	20021	1 2 3 6
equalDOF	2409	20036	1 2 3 6
equalDOF	2509	20051	1 2 3 6
equalDOF	2609	20071	1 2 3 6
equalDOF	2709	51001	1 2 3 6

# Columns of interest - MUSTESIN
equalDOF	2817	51021	1 2 3 6
equalDOF	2917	51051	1 2 3 6

equalDOF	3009	51071	1 2 3 6
equalDOF	3109	68028	1 2 3 6
equalDOF	3209	68051	1 2 3 6
equalDOF	3309	82001	1 2 3 6
equalDOF	3409	82021	1 2 3 6
equalDOF	3509	82036	1 2 3 6
equalDOF	3609	82051	1 2 3 6
equalDOF	3709	82071	1 2 3 6

# Column mastering beams' translation and rotations
equalDOF	2109	901		1 2 3 4 5 6
equalDOF	2209	117		1 2 3 4 5 6
equalDOF	2309	317		1 2 3 4 5 6
equalDOF	2409	917		1 2 3 4 5 6
equalDOF	2509	617		1 2 3 4 5 6
equalDOF	2609	817		1 2 3 4 5 6
equalDOF	2709	149		1 2 3 4 5 6

# Columns of interest - MUSTESIN
equalDOF	2817	349		1 2 3 4 5 6
equalDOF	2917	649		1 2 3 4 5 6

equalDOF	3009	849		1 2 3 4 5 6
equalDOF	3109	468		1 2 3 4 5 6
equalDOF	3209	667		1 2 3 4 5 6
equalDOF	3309	181		1 2 3 4 5 6
equalDOF	3409	381		1 2 3 4 5 6
equalDOF	3509	982		1 2 3 4 5 6
equalDOF	3609	682		1 2 3 4 5 6
equalDOF	3709	881		1 2 3 4 5 6

equalDOF	2109	1401	1 2 3 4 5 6
equalDOF	2209	118		1 2 3 4 5 6
equalDOF	2309	318		1 2 3 4 5 6
equalDOF	2409	1137	1 2 3 4 5 6
equalDOF	2509	618		1 2 3 4 5 6
equalDOF	2609	818		1 2 3 4 5 6
equalDOF	2709	150		1 2 3 4 5 6

# Columns of interest - MUSTESIN
equalDOF	2817	350		1 2 3 4 5 6
equalDOF	2917	650		1 2 3 4 5 6

equalDOF	3009	850		1 2 3 4 5 6
equalDOF	3109	1508	1 2 3 4 5 6
equalDOF	3209	668		1 2 3 4 5 6
equalDOF	3309	1301	1 2 3 4 5 6
equalDOF	3409	1321	1 2 3 4 5 6
equalDOF	3509	1337	1 2 3 4 5 6
equalDOF	3609	1353	1 2 3 4 5 6
equalDOF	3709	1374	1 2 3 4 5 6

equalDOF	2209	1101	1 2 3 4 5 6
equalDOF	2309	1121	1 2 3 4 5 6
equalDOF	2409	1138	1 2 3 4 5 6
equalDOF	2509	1153	1 2 3 4 5 6
equalDOF	2609	1174	1 2 3 4 5 6
equalDOF	2709	1201	1 2 3 4 5 6

# Columns of interest - MUSTESIN
equalDOF	2817	1221	1 2 3 4 5 6
equalDOF	2917	1253	1 2 3 4 5 6

equalDOF	3009	1274	1 2 3 4 5 6
equalDOF	3109	1509	1 2 3 4 5 6
equalDOF	3209	1532	1 2 3 4 5 6
equalDOF	3409	1322	1 2 3 4 5 6
equalDOF	3509	1338	1 2 3 4 5 6
equalDOF	3609	1354	1 2 3 4 5 6

equalDOF	2309	1122	1 2 3 4 5 6
equalDOF	2509	1154	1 2 3 4 5 6

# Columns of interest - MUSTESIN
equalDOF	2817	1222	1 2 3 4 5 6
equalDOF	2917	1254	1 2 3 4 5 6


# Vertical beams
# Primary beams
# for {set i 2} {$i < 71} {incr i 1} {
for {set i 2} {$i < 71} {incr i 1} {
	set slabC [expr 20000 + $i]
	set slabB [expr 51000 + $i]
	set slabA [expr 82000 + $i]
	if {$i <= 20} { 
		set beamC [expr 1100 + $i]
		set beamB [expr 1200 + $i]
		set beamA [expr 1300 + $i]
	} elseif {$i >= 22 && $i <= 35} {
		set beamC [expr 1100 + $i + 1]
		set beamB [expr 1200 + $i + 1]
		set beamA [expr 1300 + $i + 1]
	} elseif {$i >= 37 && $i <= 50} {
		set beamC [expr 1100 + $i + 2]
		set beamB [expr 1200 + $i + 2]
		set beamA [expr 1300 + $i + 2]
	} elseif {$i >= 52} {
		set beamC [expr 1100 + $i + 3]
		set beamB [expr 1200 + $i + 3]
		set beamA [expr 1300 + $i + 3]
	}
	
	if {$i == 36} {
		rigidLink beam $slabB 1237
		rigidLink beam $slabB 1238
	}
	
	if {$i != 21 && $i != 36 && $i != 51} {
		# puts "rigid link between slab: $slabC and beam: $beamC"
		rigidLink beam $slabC $beamC
		rigidLink beam $slabB $beamB
		if {$slabA <= 82035 || $slabA >= 82052 } {
			rigidLink beam $slabA $beamA
		}
	}
}
# Beam 1400
for {set i 1} {$i <= 15} {incr i 1} {
	rigidLink beam [expr 4036 + $i] [expr 1401 + $i]
}
# Beam 1500
for {set i 1} {$i <= 31} {incr i 1} {
	if {$i <= 7} {
		rigidLink beam [expr 68020 + $i] [expr 1500 + $i]
	} elseif {$i >= 10} {
		rigidLink beam [expr 68019 + $i] [expr 1500 + $i]
	}
}

# Beams 1600 & 1700
rigidLink beam 7026 1601
rigidLink beam 16026 1701
rigidLink beam 7036 1611
rigidLink beam 16036 1711

# Horizontal beams
# Primary beams
# Beams 100, 300, and 800

# for {set i 1} {$i <= 78} {incr i 1} {
for {set i 2} {$i <= 78} {incr i 1} {
	set slab100 [expr 4001 + ($i - 1)*1000]
	set slab300 [expr 4021 + ($i - 1)*1000]
	set slab800 [expr 4071 + ($i - 1)*1000]
	if {$i <= 16} {
		set beam100 [expr 100 + $i]
		set beam300 [expr 300 + $i]
		set beam800 [expr 800 + $i]
	} elseif {$i >= 18 && $i <= 47} {
		set beam100 [expr 100 + $i + 1]
		set beam300 [expr 300 + $i + 1]
		set beam800 [expr 800 + $i + 1]
	} elseif {$i >= 49 && $i <= 78} {
		set beam100 [expr 100 + $i + 2]
		set beam300 [expr 300 + $i + 2]
		set beam800 [expr 800 + $i + 2]
	}
	if {$i != 17 && $i != 48} {
		rigidLink beam  $slab100 $beam100
		# puts "rigidLink 100: $slab100 $beam100"	
		rigidLink beam  $slab300 $beam300
		# puts "rigidLink 300: $slab300 $beam300"
		rigidLink beam $slab800 $beam800
		# puts "rigidLink 800: $slab800 $beam800"
	}
}
# Beams 200 and 700
for {set i 2} {$i <= 81} {incr i 1} {
	set beam200 [expr 200 + $i]
	set beam700 [expr 700 + $i]
	if {$i <= 17} {
		set slab200 [expr 4011 + ($i - 1)*1000]
		set slab700 [expr 4061 + ($i - 1)*1000]
	} elseif {$i >= 18 && $i <= 49} {
		set slab200 [expr 4011 + ($i - 2)*1000]
		set slab700 [expr 4061 + ($i - 2)*1000]
	} elseif {$i >= 50 && $i <= 81} {
		set slab200 [expr 4011 + ($i - 3)*1000]
		set slab700 [expr 4061 + ($i - 3)*1000]
	}
	rigidLink beam  $slab200 $beam200
	# puts "rigidLink 200: $slab200 $beam200"	
	rigidLink beam $slab700 $beam700
	# puts "rigidLink 700: $slab700 $beam700"
}

# Beams 400, 500, and 600
# for {set i 1} {$i <= 82} {incr i 1} {
for {set i 1} {$i <= 82} {incr i 1} {
	set beam400 [expr 400 + $i]
	set beam500 [expr 500 + $i]
	set beam600 [expr 600 + $i]
	if {$i <= 17} {
		set slab400 [expr 4026 + ($i - 1)*1000]
		set slab500 [expr 4041 + ($i - 1)*1000]
		set slab600 [expr 4051 + ($i - 1)*1000]
	} elseif {$i >= 18 && $i <= 49} {
		set slab400 [expr 4031 + ($i - 2)*1000]
		set slab500 [expr 4041 + ($i - 2)*1000]
		set slab600 [expr 4051 + ($i - 2)*1000]
	} elseif {$i >= 50 && $i <= 67} {
		set slab400 [expr 4031 + ($i - 3)*1000]
		set slab500 [expr 4041 + ($i - 3)*1000]
		set slab600 [expr 4051 + ($i - 3)*1000]
	} elseif {$i >= 68 && $i <= 82} {
		set slab400 [expr 4028 + ($i - 4)*1000]
		set slab500 [expr 4031 + ($i - 4)*1000]
		set slab600 [expr 4051 + ($i - 4)*1000]
	} 
	if {$i != 68} {
		rigidLink beam $slab400 $beam400
		# puts "rigidLink 400: $slab400 $beam400"	
	}
	rigidLink beam $slab500 $beam500
	# puts "rigidLink 500: $slab500 $beam500"
	
	if {$i != 17 && $i != 18 && $i != 49 && $i != 50 && $i != 67 && $i != 68 && $i != 82} {
		rigidLink beam $slab600 $beam600
		# puts "rigidLink 600: $slab600 $beam600"		
	}
}

# beam 900
for {set i 2} {$i <= 16} {incr i 1} {
	rigidLink beam [expr 4036 + ($i - 1)*1000] [expr 900 + $i]
	# puts "rigidLink 900: [expr 4036 + ($i - 1)*1000] [expr 900 + $i]"
}
for {set i 68} {$i <= 81} {incr i 1} {
	rigidLink beam [expr 4036 + ($i - 4)*1000] [expr 900 + $i]
	# puts "rigidLink 900: [expr 4036 + ($i - 4)*1000] [expr 900 + $i]"
}
