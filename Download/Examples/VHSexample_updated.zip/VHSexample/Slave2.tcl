## Revisino Log

## Revised on 07/19
## Temp was loaded
## Shell element used
## RigidLink on the top Plate

## Revised on 07/26
## Re-define the nodes and meshes

## Revised on 07/30
## Change the section of Chou, Change the OpenSEES Version
## Change the elongation

wipe;

# ------------------------------
# Start of model generation
# ------------------------------
# create ModelBuilder (with two-dimensions and 2 DOF/node)

## 0524 Make sure the system coordinate is same as master.tcl
model BasicBuilder -ndm 3 -ndf 6
logFile "Hybrid20210731_slave.log"
## 800 mm in fire 
# Load OpenFresco package
# -----------------------
# (make sure all dlls are in the same folder as openSees.exe)
loadPackage OpenFresco

# Define geometry for model Nodes of 1 flange



# -------------------------
# node $tag $xCrd $yCrd
# Define materials

source DisplayPlane.tcl
source DisplayModel2D.tcl
source DisplayModel3D.tcl

#source LibUnits.tcl;           # define units
#source DisplayPlane.tcl;       # procedure for displaying a plane in model
#source DisplayModel3D.tcl; 


#set K 1.3e11;
#set G 0.75e11;
#set sig0 455e6;
#set sigInf 555e6;
# To consistent the unit
set K 1.3e5;
set G 0.75e5;
set sig0 455;
set sigInf 555;

set delta 1;
set H 0;

#set delta2 0;
set mDen  7800;


#nDMaterial J2Thermal 4 3 $K $G $sig0 $sigInf $delta $H 0;

# Another option for J2 plasticity
#nDMaterial  J2PlaneStressThermal $tag $typeTag $nu $fy $fu $hardening factor
#nDMaterial  J2PlaneStressThermal 4 3 2e11 0.3 4.68e8 6.00e8 0.1 2e8;
# Unit issue
# nDMaterial ElasticIsotropic3DThermal $matTag $E0 $Poisson_ratio $Density $Thermal_expansion_ratio
## nDMaterial ElasticIsotropic3DThermal 4 2.1e5 0.3 0 1.4e-5;

#nDMaterial ElasticIsotropic3DThermal 4 2.1e5 0.3 0 1.0e-5;
#nDMaterial ElasticIsotropic3DThermal 4 2.1e5 0.3 0 1.4e-5;
nDMaterial ElasticIsotropic3DThermal 4 2.1e5 0.3 0 1.4e-5;
nDMaterial PlateFiberThermal    2   4

#nDMaterial  J2PlaneStressThermal 4 3 2.1e5 0.3 4.68e2 6.00e2 0.1 2e8;
#nDMaterial   PlateFromPlaneStressThermal    2   4   20e10;
### For two-node link element
#uniaxialMaterial Elastic 100 1e6
#
#    # // EN 1992&1993
#    # //typeTag:3   EC3 Structural Steel
#    # //typeTag:21  EC2 Reinforcing Steel EC2 NHotRolled
#    # //typeTag:22  EC2 Reinforcing Steel EC2 NCold formed
#    # //typeTag:23  EC2 Reinforcing Steel EC2 X
#
#
## On 0524
##section LayeredShellThermal  3  4  2  0.004  2  0.004 2  0.004 2  0.004   ;
##section LayeredShellThermal  2  4  2  0.003  2  0.003 2  0.003 2  0.003;
# for web section
section LayeredShellThermal  2  4  2  3.45  2  3.45 2  3.45 2  3.45  ;
# for flange section
section LayeredShellThermal  3  4  2  5.43  2  5.43 2  5.43 2  5.43  ;
#
#section LayeredShellThermal  2  8  2  1.73  2  1.73 2  1.73  2  1.73 2  1.73  2  1.73 2  1.73  2  1.73;
#section LayeredShellThermal  3  8  2  2.72  2  2.72 2  2.72  2  2.72 2  2.72  2  2.72 2  2.72  2  2.72;
#

node    1   0   0   0
node    2   0   0   100
node    3   0   0   200
node    4   0   0   300
node    5   0   0   400
node    6   0   0   500
node    7   0   0   600
node    8   0   0   700
node    9   0   0   800
node    10  0   0   900
node    11  0   0   1000
node    12  0   0   1100
node    13  0   0   1200
node    14  0   0   1300
node    15  0   0   1400
node    16  0   0   1500
node    17  0   0   1600
node    18  0   0   1700
node    19  0   0   1800
node    20  0   0   1900
node    21  0   0   2000
node    22  0   0   2100
node    23  0   0   2200
node    24  0   0   2300
node    25  0   0   2400
node    26  0   0   2500
node    27  0   0   2600
node    28  0   0   2700
node    29  0   0   2800
node    30  0   0   2900
node    31  0   0   3000
node    32  0   0   3100
node    33  0   0   3200
node    34  0   0   3300
node    35  0   0   3400
node    36  0   0   3500
node    37  0   0   3600
node    38  0   0   3700
node    39  0   0   3800
node    40  0   0   3900
node    41  0   0   4000

node    42  0   -80.1   0
node    43  0   -80.1   100
node    44  0   -80.1   200
node    45  0   -80.1   300
node    46  0   -80.1   400
node    47  0   -80.1   500
node    48  0   -80.1   600
node    49  0   -80.1   700
node    50  0   -80.1   800
node    51  0   -80.1   900
node    52  0   -80.1   1000
node    53  0   -80.1   1100
node    54  0   -80.1   1200
node    55  0   -80.1   1300
node    56  0   -80.1   1400
node    57  0   -80.1   1500
node    58  0   -80.1   1600
node    59  0   -80.1   1700
node    60  0   -80.1   1800
node    61  0   -80.1   1900
node    62  0   -80.1   2000
node    63  0   -80.1   2100
node    64  0   -80.1   2200
node    65  0   -80.1   2300
node    66  0   -80.1   2400
node    67  0   -80.1   2500
node    68  0   -80.1   2600
node    69  0   -80.1   2700
node    70  0   -80.1   2800
node    71  0   -80.1   2900
node    72  0   -80.1   3000
node    73  0   -80.1   3100
node    74  0   -80.1   3200
node    75  0   -80.1   3300
node    76  0   -80.1   3400
node    77  0   -80.1   3500
node    78  0   -80.1   3600
node    79  0   -80.1   3700
node    80  0   -80.1   3800
node    81  0   -80.1   3900
node    82  0   -80.1   4000

node    83  0   -160.2  0
node    84  0   -160.2  100
node    85  0   -160.2  200
node    86  0   -160.2  300
node    87  0   -160.2  400
node    88  0   -160.2  500
node    89  0   -160.2  600
node    90  0   -160.2  700
node    91  0   -160.2  800
node    92  0   -160.2  900
node    93  0   -160.2  1000
node    94  0   -160.2  1100
node    95  0   -160.2  1200
node    96  0   -160.2  1300
node    97  0   -160.2  1400
node    98  0   -160.2  1500
node    99  0   -160.2  1600
node    100 0   -160.2  1700
node    101 0   -160.2  1800
node    102 0   -160.2  1900
node    103 0   -160.2  2000
node    104 0   -160.2  2100
node    105 0   -160.2  2200
node    106 0   -160.2  2300
node    107 0   -160.2  2400
node    108 0   -160.2  2500
node    109 0   -160.2  2600
node    110 0   -160.2  2700
node    111 0   -160.2  2800
node    112 0   -160.2  2900
node    113 0   -160.2  3000
node    114 0   -160.2  3100
node    115 0   -160.2  3200
node    116 0   -160.2  3300
node    117 0   -160.2  3400
node    118 0   -160.2  3500
node    119 0   -160.2  3600
node    120 0   -160.2  3700
node    121 0   -160.2  3800
node    122 0   -160.2  3900
node    123 0   -160.2  4000

node    124 0   80.1    0
node    125 0   80.1    100
node    126 0   80.1    200
node    127 0   80.1    300
node    128 0   80.1    400
node    129 0   80.1    500
node    130 0   80.1    600
node    131 0   80.1    700
node    132 0   80.1    800
node    133 0   80.1    900
node    134 0   80.1    1000
node    135 0   80.1    1100
node    136 0   80.1    1200
node    137 0   80.1    1300
node    138 0   80.1    1400
node    139 0   80.1    1500
node    140 0   80.1    1600
node    141 0   80.1    1700
node    142 0   80.1    1800
node    143 0   80.1    1900
node    144 0   80.1    2000
node    145 0   80.1    2100
node    146 0   80.1    2200
node    147 0   80.1    2300
node    148 0   80.1    2400
node    149 0   80.1    2500
node    150 0   80.1    2600
node    151 0   80.1    2700
node    152 0   80.1    2800
node    153 0   80.1    2900
node    154 0   80.1    3000
node    155 0   80.1    3100
node    156 0   80.1    3200
node    157 0   80.1    3300
node    158 0   80.1    3400
node    159 0   80.1    3500
node    160 0   80.1    3600
node    161 0   80.1    3700
node    162 0   80.1    3800
node    163 0   80.1    3900
node    164 0   80.1    4000

node    165 0   160.2   0
node    166 0   160.2   100
node    167 0   160.2   200
node    168 0   160.2   300
node    169 0   160.2   400
node    170 0   160.2   500
node    171 0   160.2   600
node    172 0   160.2   700
node    173 0   160.2   800
node    174 0   160.2   900
node    175 0   160.2   1000
node    176 0   160.2   1100
node    177 0   160.2   1200
node    178 0   160.2   1300
node    179 0   160.2   1400
node    180 0   160.2   1500
node    181 0   160.2   1600
node    182 0   160.2   1700
node    183 0   160.2   1800
node    184 0   160.2   1900
node    185 0   160.2   2000
node    186 0   160.2   2100
node    187 0   160.2   2200
node    188 0   160.2   2300
node    189 0   160.2   2400
node    190 0   160.2   2500
node    191 0   160.2   2600
node    192 0   160.2   2700
node    193 0   160.2   2800
node    194 0   160.2   2900
node    195 0   160.2   3000
node    196 0   160.2   3100
node    197 0   160.2   3200
node    198 0   160.2   3300
node    199 0   160.2   3400
node    200 0   160.2   3500
node    201 0   160.2   3600
node    202 0   160.2   3700
node    203 0   160.2   3800
node    204 0   160.2   3900
node    205 0   160.2   4000

node    206 -154.4  -160.2  0
node    207 -154.4  -160.2  100
node    208 -154.4  -160.2  200
node    209 -154.4  -160.2  300
node    210 -154.4  -160.2  400
node    211 -154.4  -160.2  500
node    212 -154.4  -160.2  600
node    213 -154.4  -160.2  700
node    214 -154.4  -160.2  800
node    215 -154.4  -160.2  900
node    216 -154.4  -160.2  1000
node    217 -154.4  -160.2  1100
node    218 -154.4  -160.2  1200
node    219 -154.4  -160.2  1300
node    220 -154.4  -160.2  1400
node    221 -154.4  -160.2  1500
node    222 -154.4  -160.2  1600
node    223 -154.4  -160.2  1700
node    224 -154.4  -160.2  1800
node    225 -154.4  -160.2  1900
node    226 -154.4  -160.2  2000
node    227 -154.4  -160.2  2100
node    228 -154.4  -160.2  2200
node    229 -154.4  -160.2  2300
node    230 -154.4  -160.2  2400
node    231 -154.4  -160.2  2500
node    232 -154.4  -160.2  2600
node    233 -154.4  -160.2  2700
node    234 -154.4  -160.2  2800
node    235 -154.4  -160.2  2900
node    236 -154.4  -160.2  3000
node    237 -154.4  -160.2  3100
node    238 -154.4  -160.2  3200
node    239 -154.4  -160.2  3300
node    240 -154.4  -160.2  3400
node    241 -154.4  -160.2  3500
node    242 -154.4  -160.2  3600
node    243 -154.4  -160.2  3700
node    244 -154.4  -160.2  3800
node    245 -154.4  -160.2  3900
node    246 -154.4  -160.2  4000

node    247 154.4   -160.2  0
node    248 154.4   -160.2  100
node    249 154.4   -160.2  200
node    250 154.4   -160.2  300
node    251 154.4   -160.2  400
node    252 154.4   -160.2  500
node    253 154.4   -160.2  600
node    254 154.4   -160.2  700
node    255 154.4   -160.2  800
node    256 154.4   -160.2  900
node    257 154.4   -160.2  1000
node    258 154.4   -160.2  1100
node    259 154.4   -160.2  1200
node    260 154.4   -160.2  1300
node    261 154.4   -160.2  1400
node    262 154.4   -160.2  1500
node    263 154.4   -160.2  1600
node    264 154.4   -160.2  1700
node    265 154.4   -160.2  1800
node    266 154.4   -160.2  1900
node    267 154.4   -160.2  2000
node    268 154.4   -160.2  2100
node    269 154.4   -160.2  2200
node    270 154.4   -160.2  2300
node    271 154.4   -160.2  2400
node    272 154.4   -160.2  2500
node    273 154.4   -160.2  2600
node    274 154.4   -160.2  2700
node    275 154.4   -160.2  2800
node    276 154.4   -160.2  2900
node    277 154.4   -160.2  3000
node    278 154.4   -160.2  3100
node    279 154.4   -160.2  3200
node    280 154.4   -160.2  3300
node    281 154.4   -160.2  3400
node    282 154.4   -160.2  3500
node    283 154.4   -160.2  3600
node    284 154.4   -160.2  3700
node    285 154.4   -160.2  3800
node    286 154.4   -160.2  3900
node    287 154.4   -160.2  4000

node    288 -154.4  160.2   0
node    289 -154.4  160.2   100
node    290 -154.4  160.2   200
node    291 -154.4  160.2   300
node    292 -154.4  160.2   400
node    293 -154.4  160.2   500
node    294 -154.4  160.2   600
node    295 -154.4  160.2   700
node    296 -154.4  160.2   800
node    297 -154.4  160.2   900
node    298 -154.4  160.2   1000
node    299 -154.4  160.2   1100
node    300 -154.4  160.2   1200
node    301 -154.4  160.2   1300
node    302 -154.4  160.2   1400
node    303 -154.4  160.2   1500
node    304 -154.4  160.2   1600
node    305 -154.4  160.2   1700
node    306 -154.4  160.2   1800
node    307 -154.4  160.2   1900
node    308 -154.4  160.2   2000
node    309 -154.4  160.2   2100
node    310 -154.4  160.2   2200
node    311 -154.4  160.2   2300
node    312 -154.4  160.2   2400
node    313 -154.4  160.2   2500
node    314 -154.4  160.2   2600
node    315 -154.4  160.2   2700
node    316 -154.4  160.2   2800
node    317 -154.4  160.2   2900
node    318 -154.4  160.2   3000
node    319 -154.4  160.2   3100
node    320 -154.4  160.2   3200
node    321 -154.4  160.2   3300
node    322 -154.4  160.2   3400
node    323 -154.4  160.2   3500
node    324 -154.4  160.2   3600
node    325 -154.4  160.2   3700
node    326 -154.4  160.2   3800
node    327 -154.4  160.2   3900
node    328 -154.4  160.2   4000

node    329 154.4   160.2   0
node    330 154.4   160.2   100
node    331 154.4   160.2   200
node    332 154.4   160.2   300
node    333 154.4   160.2   400
node    334 154.4   160.2   500
node    335 154.4   160.2   600
node    336 154.4   160.2   700
node    337 154.4   160.2   800
node    338 154.4   160.2   900
node    339 154.4   160.2   1000
node    340 154.4   160.2   1100
node    341 154.4   160.2   1200
node    342 154.4   160.2   1300
node    343 154.4   160.2   1400
node    344 154.4   160.2   1500
node    345 154.4   160.2   1600
node    346 154.4   160.2   1700
node    347 154.4   160.2   1800
node    348 154.4   160.2   1900
node    349 154.4   160.2   2000
node    350 154.4   160.2   2100
node    351 154.4   160.2   2200
node    352 154.4   160.2   2300
node    353 154.4   160.2   2400
node    354 154.4   160.2   2500
node    355 154.4   160.2   2600
node    356 154.4   160.2   2700
node    357 154.4   160.2   2800
node    358 154.4   160.2   2900
node    359 154.4   160.2   3000
node    360 154.4   160.2   3100
node    361 154.4   160.2   3200
node    362 154.4   160.2   3300
node    363 154.4   160.2   3400
node    364 154.4   160.2   3500
node    365 154.4   160.2   3600
node    366 154.4   160.2   3700
node    367 154.4   160.2   3800
node    368 154.4   160.2   3900
node    369 154.4   160.2   4000


#node    666 0       0       4000
#node     1    0    0    0
#node     2    0    0    500
#node     3    0    0    1000
#node     4    0    0    1500
#node     5    0    0    2000
#node     6    0    0    2500
#node     7    0    0    3000
#node     8    0    0    3500
#node     9    0    0    4000

#fix    101 1   1   1   0   0   0
#fix    125 0   1   1   0   0   0

#fix    201 1   1   1   0   0   0
#fix    225 0   1   1   0   0   0
#fix    176 1   1   1   0   0   0
#fix    200 0   1   1   0   0   0

# for beam-column element
#fix 1   1   1   1   1   1   1
#fix 9   1   1   0   0   0   0
fix 1   1   1   1   1   1   1
fix 42  1   1   1   1   1   1
fix 83  1   1   1   1   1   1
fix 124 1   1   1   1   1   1
fix 165 1   1   1   1   1   1
fix 206 1   1   1   1   1   1
fix 247 1   1   1   1   1   1
fix 288 1   1   1   1   1   1
fix 329 1   1   1   1   1   1

#fix 41   1   0   0   0   0   0
#fix 82   1   0   0   0   0   0
#fix 123  1   0   0   0   0   0
#fix 164  1   0   0   0   0   0
#fix 205  1   0   0   0   0   0
#fix 246  1   0   0   0   0   0
#fix 287  1   0   0   0   0   0
#fix 328  1   0   0   0   0   0
#fix 369  1   0   0   0   0   0

#rigidLink beam 41 82
rigidLink beam 41 123
#rigidLink beam 41 164
rigidLink beam 41 205
#rigidLink beam 41 246
#rigidLink beam 41 287
#rigidLink beam 41 328
#rigidLink beam 41 369

#rigidLink beam 82  41 
#rigidLink beam 123 41 
#rigidLink beam 164 41 
#rigidLink beam 205 41 
#rigidLink beam 246 41 
#rigidLink beam 287 41 
#rigidLink beam 328 41 
#rigidLink beam 369 41 

# element ShellMITC4Thermal $eleTag $iNode $jNode $kNode $lNode $secTag;
# For web
for {set i 1} {$i <= 40} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 + 41]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 2
    }

for {set i 42} {$i <= 81} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 + 41]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 2
    }

for {set i 124} {$i <= 163} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 -123]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 2
    }

for {set i 165} {$i <= 204} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 -41]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 2
    }

## For flange
for {set i 83} {$i <= 122} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 + 164]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 3
    }

for {set i 206} {$i <= 245} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 - 123]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 3
    }

for {set i 288} {$i <= 327} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 - 123]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 3
    }

for {set i 329} {$i <= 368} {incr i} {
    set node1 [expr $i]
    set node2 [expr $i + 1]
    set node3 [expr $node2 - 164]
    set node4 [expr $node3 - 1]
    set eleID [expr $i]
    element  ShellMITC4Thermal  $eleID $node1 $node2 $node3 $node4 3
    }


#fix    101 1   1   1   0   0   0
#fix    125 0   1   1   0   0   0
#fix    201 1   1   1   0   0   0
#fix    225 0   1   1   0   0   0
#fix    176 1   1   1   0   0   0
#fix    200 0   1   1   0   0   0

## End comment                      

# element  adapter 1000000  -node 25 -dof 3     -stif  3E+09  44000
#element  adapter 1000000  -node 25 -dof 1 2 3 -stif 9e6 0 0 0 9e6 0 0 0 1e12 44000
# element adapter 1000000 -node 25 -dof 3 -stif 1e6 44000
## 0712 changed as the larger values
## 0713 Kx = 1050; ky = 3200; kz = 9.1e5
# Stiffness
## for shell element
#element  adapter 1000000  -node 25 -dof 1 2 3 -stif 100 0 0 0 220 0 0 0 8.7e5 44000
#element  adapter 10000  -node 41 -dof 1 2 3 -stif 1.1e6 0 0 0 1.0e7 0 0 0 8.3e11 44000
element  adapter 10001  -node 41 -dof 1 2 3 -stif 1.0e3 0 0 0 4.8e3 0 0 0 2.0e7 43000
#element  adapter 10000  -node 41 -dof 3 -stif 8.3e11 44000
## Square stiffness
# for beam-column element
#element  adapter 10000  -node 9 -dof 1 2 3 -stif 1.0e4 0 0 0 4.8e4 0 0 0 7.5e11 44000
#element  adapter 10000  -node 25 -dof 3 -stif 7.5e11 44000
## Cube stiffness
#element  adapter 1000000  -node 25 -dof 1 2 3 -stif 1.0e6 0 0 0 1.0e7 0 0 0 6.6e17 44000


# Define DISPLAY -------------------------------------------------------------
# Comment 0419
set  xPixels 1200;  # height of graphical window in pixels
set  yPixels 800;   # height of graphical window in pixels
set  xLoc1 10;  # horizontal location of graphical window (0=upper left-most corner)
set  yLoc1 10;  # vertical location of graphical window (0=upper left-most corner)
set  dAmp  1.0;    # scaling factor for viewing deformed shape, it depends on the dimensions of the model
#DisplayModel3D NodeNumbers $dAmp $xLoc1 $yLoc1  $xPixels $yPixels
#DisplayModel3D DeformedShape $dAmp $xLoc1 $yLoc1  $xPixels $yPixels
#
#recorder Element -file ShellData/EleForceSec2Tempm.out -time -ele 153   material 2 fiber 2 TempAndElong;
#recorder Element -file ShellData/EleForceSec2stressm.out -time -ele 10  material 2 fiber 2 stress;  
#
#recorder Element -file ShellData/EleForceSec2stress1m.out -time -ele 1  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress20m.out -time -ele 20  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress22m.out -time -ele 22  material 2 fiber 2 stress;
#
#recorder Element -file ShellData/EleForceSec2stress81m.out -time -ele 81  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress90m.out -time -ele 90  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress121m.out -time -ele 122  material 2 fiber 2 stress;
#recorder Element -file ShellData/EleForceSec2stress130m.out -time -ele 130  material 2 fiber 2 stress;
#
#recorder Element -file ShellData/EleForceSec2strainm.out -time -ele 10  material 2 fiber 2 strain;

#recorder Node -file BaseNode1.out   -time -node 1    -dof 1 2 3 4 5 6  disp
#recorder Node -file BaseNode101.out -time -node 101  -dof 1 2 3 4 5 6  disp
recorder Node -file MidNode41.out   -time -node 41   -dof 1 2 3 4 5 6  disp
recorder Node -file MidNode205.out  -time -node 205  -dof 1 2 3 4 5 6  disp
#recorder Node -file DFreeSlabyT16m.out -time -nodeRange 126  150 -dof 2 disp;
#recorder Node -file DFreeSlabyT163m.out -time -nodeRange 176  200 -dof 2 disp;
##
#recorder Node -file DFreeSlabyTwebottom.out -time -nodeRange 101 125 -dof 3 disp;
#recorder Node -file DFreeSlabyTwebtop.out -time -nodeRange 76 100 -dof 3 disp;
#recorder Node -file DFreeSlabyT13m.out -time -nodeRange 1 25 -dof 3 disp;
#
#recorder Node -file DFreeSlabyT14m.out -time -nodeRange 26  50 -dof 3 disp;
#
#recorder Node -file DFreeSlabyT15m.out -time -nodeRange 51 75 -dof 3 disp;
#set  xPixels 1200; # height of graphical window in pixels
#set  yPixels 800; # height of graphical window in pixels
#set  xLoc1 10; # horizontal location of graphical window (0=upper left-most corner)
#set  yLoc1 10; # vertical location of graphical window (0=upper left-most corner)
#set ViewScale 1.0e-5; # scaling factor for viewing deformed shape, it depends on the dimensions of the model

puts "nodal coordinates defined"

# Comment on 0520
# set UDLP 43;
#set UDLP 15687.0;
## set UDLP 0
#
#pattern Plain 1 Linear {
#   
#    
#
#load    25  0   0 -$UDLP  0   0   0     ;
#
#  
#}
#constraints Plain;
#numberer Plain;
#system SparseSYM;
#test NormDispIncr 1e-2  50;
#algorithm Newton;
#integrator LoadControl 1.0; 
#analysis Static; 
## 0524 modified           
##analyze 10;
#analyze 10000
set UDLP 1.0
pattern Plain 1 Linear {
    load    41  0   0 -$UDLP  0   0   0     ;
}
constraints Transformation;             
numberer Plain;           
system SparseSYM;
test FixedNumIter 1  1
#integrator NewmarkHSFixedNumIter 0.5 0.25
integrator LoadControl 0.04
algorithm Newton               
analysis Static;
# To be coincided
analyze 25
puts "gravity completed"

#-------------------------------- 
#End of analysis 
#--------------------------------
#loadConst -time 0.0
## 500.0 mm column unprotected
pattern Plain 2 Linear {
    # for beam-column element
    #eleLoad -ele 107  -type -beamThermal -source "temps/colB2.dat"     -157.0 157.0 -78.0 78.0;
    for {set i 36} {$i <= 40} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -6.9  6.9
    }  
    for {set i 77} {$i <= 81} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -6.9  6.9
    }
    for {set i 159} {$i <= 163} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -6.9  6.9
    }
    for {set i 200} {$i <= 204} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -6.9  6.9
    }
    ## for heating the flanges
    for {set i 118} {$i <= 122} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -10.86 10.86
    }
    for {set i 241} {$i <= 245} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -10.86 10.86
    }
    for {set i 323} {$i <= 327} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -10.86 10.86
    }
    for {set i 364} {$i <= 368} {incr i 1} {
    eleLoad -ele $i -type -shellThermal -source "temps/colB2_shell.dat" -10.86 10.86
    }
}

#wipeAnalysis;
constraints Transformation;
numberer Plain;
system UmfPack
#system SparseSYM;
##test NormDispIncr 1e-4  25;
##algorithm Newton;
##integrator LoadControl 1.0;
## the max number of iterations to perform
## 1 print information on energy norm each time test() is invoked

## Set the time = 90.0
test FixedNumIter 5 1
#integrator LoadControl 0.1
integrator LoadControl 0.1
algorithm Newton
analysis Static; 
#analyze 450
#analyze 1000
analyze 1000







