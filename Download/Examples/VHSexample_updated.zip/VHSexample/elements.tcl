geomTransf Corotational 11 0 -1 0
geomTransf Corotational 22 -1 0 0
geomTransf Corotational 33 -1 0 0
## For experimental element 0702
geomTransf Linear 44 -1 0 0

# horizontal beams
for {set i 1} {$i < $endNode1} {incr i 1} {
    element dispBeamColumnThermal [expr $i + 100] [expr $i + 100] [expr $i + 101] 5 $UB356 11
    element dispBeamColumnThermal [expr $i + 200] [expr $i + 200] [expr $i + 201] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 300] [expr $i + 300] [expr $i + 301] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 400] [expr $i + 400] [expr $i + 401] 5 $UB356 11
    element dispBeamColumnThermal [expr $i + 900] [expr $i + 900] [expr $i + 901] 5 $UB356 11
    element dispBeamColumnThermal [expr $i + 500] [expr $i + 500] [expr $i + 501] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 600] [expr $i + 600] [expr $i + 601] 5 $UB356 11
    element dispBeamColumnThermal [expr $i + 700] [expr $i + 700] [expr $i + 701] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 800] [expr $i + 800] [expr $i + 801] 5 $UB356 11
}
for {set i [expr $endNode1 + 1]} {$i < $endNode2} {incr i 1} {
    element dispBeamColumnThermal [expr $i + 100] [expr $i + 100] [expr $i + 101] 5 $UB356 11
    element dispBeamColumnThermal [expr $i + 200] [expr $i + 200] [expr $i + 201] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 300] [expr $i + 300] [expr $i + 301] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 400] [expr $i + 400] [expr $i + 401] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 500] [expr $i + 500] [expr $i + 501] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 600] [expr $i + 600] [expr $i + 601] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 700] [expr $i + 700] [expr $i + 701] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 800] [expr $i + 800] [expr $i + 801] 5 $UB356 11
}
for {set i [expr $endNode2 + 1]} {$i < $endNode3} {incr i 1} {
    element dispBeamColumnThermal [expr $i + 100] [expr $i + 100] [expr $i + 101] 5 $UB356 11
    element dispBeamColumnThermal [expr $i + 200] [expr $i + 200] [expr $i + 201] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 300] [expr $i + 300] [expr $i + 301] 5 $UB305 11
    if {$i < 67} {
        element dispBeamColumnThermal [expr $i + 400] [expr $i + 400] [expr $i + 401] 5 $UB305 11
        element dispBeamColumnThermal [expr $i + 500] [expr $i + 500] [expr $i + 501] 5 $UB305 11
        element dispBeamColumnThermal [expr $i + 600] [expr $i + 600] [expr $i + 601] 5 $UB305 11
    } elseif {$i >= 67} {
        element dispBeamColumnThermal [expr $i + 900] [expr $i + 901] [expr $i + 902] 5 $UB356 11
        element dispBeamColumnThermal [expr $i + 400] [expr $i + 401] [expr $i + 402] 5 $UB356 11
        element dispBeamColumnThermal [expr $i + 500] [expr $i + 501] [expr $i + 502] 5 $UB356 11
        element dispBeamColumnThermal [expr $i + 600] [expr $i + 601] [expr $i + 602] 5 $UB356 11
    }
    element dispBeamColumnThermal [expr $i + 700] [expr $i + 700] [expr $i + 701] 5 $UB305 11
    element dispBeamColumnThermal [expr $i + 800] [expr $i + 800] [expr $i + 801] 5 $UB356 11
}

# Vertical beams
for {set i 1} {$i < $endNode1v} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1100] [expr $i + 1100] [expr $i + 1101] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1200] [expr $i + 1200] [expr $i + 1201] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1300] [expr $i + 1300] [expr $i + 1301] 5 $UB356 22
}
for {set i [expr $endNode1v + 1]} {$i < $endNode2v} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1100] [expr $i + 1100] [expr $i + 1101] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1200] [expr $i + 1200] [expr $i + 1201] 5 $UB610 22
        element dispBeamColumnThermal [expr $i + 1300] [expr $i + 1300] [expr $i + 1301] 5 $UB356 22
}
for {set i [expr $endNode2v + 1]} {$i < $endNode3v} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1100] [expr $i + 1100] [expr $i + 1101] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1200] [expr $i + 1200] [expr $i + 1201] 5 $UB610 22
        element dispBeamColumnThermal [expr $i + 1300] [expr $i + 1300] [expr $i + 1301] 5 $UB356 22
}
for {set i [expr $endNode3v + 1]} {$i < $endNode4v} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1100] [expr $i + 1100] [expr $i + 1101] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1200] [expr $i + 1200] [expr $i + 1201] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1300] [expr $i + 1300] [expr $i + 1301] 5 $UB356 22
}

# beam 1400
for {set i 1} {$i < 16} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1400] [expr $i + 1400] [expr $i + 1401] 5 $UB356 22
}

# beam 1500
for {set i 1} {$i <= 7} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1500] [expr $i + 1500] [expr $i + 1501] 5 $UB356 22
}
for {set i 9} {$i <= 31} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1500] [expr $i + 1500] [expr $i + 1501] 5 $UB356 22
}

# beams 1600 & 1700
for {set i 1} {$i <= 10} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 1600] [expr $i + 1600] [expr $i + 1601] 5 $UB356 22
        element dispBeamColumnThermal [expr $i + 1700] [expr $i + 1700] [expr $i + 1701] 5 $UB356 22
}

# Columns 
for {set i 1} {$i <= [expr abs($zlimi - $zlimf)/$colL]} {incr i 1} {
        element dispBeamColumnThermal [expr $i + 2100] [expr $i + 2100] [expr $i + 2101] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 2200] [expr $i + 2200] [expr $i + 2201] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 2300] [expr $i + 2300] [expr $i + 2301] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 2400] [expr $i + 2400] [expr $i + 2401] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 2500] [expr $i + 2500] [expr $i + 2501] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 2600] [expr $i + 2600] [expr $i + 2601] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 2700] [expr $i + 2700] [expr $i + 2701] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3000] [expr $i + 3000] [expr $i + 3001] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3100] [expr $i + 3100] [expr $i + 3101] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3200] [expr $i + 3200] [expr $i + 3201] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3300] [expr $i + 3300] [expr $i + 3301] 5 $UC254 33
        element dispBeamColumnThermal [expr $i + 3400] [expr $i + 3400] [expr $i + 3401] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3500] [expr $i + 3500] [expr $i + 3501] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3600] [expr $i + 3600] [expr $i + 3601] 5 $UC305 33
        element dispBeamColumnThermal [expr $i + 3700] [expr $i + 3700] [expr $i + 3701] 5 $UC254 33
}
# Columns of interest - MUSTESIN
# Columns B2 and B3 - the important ones        
for {set i 17} {$i < 25} {incr i 1} {
    #element dispBeamColumnThermal [expr $i + 2800] [expr $i + 2800] [expr $i + 2801] 5 $UC305 33
    element dispBeamColumnThermal [expr $i + 2900] [expr $i + 2900] [expr $i + 2901] 5 $UC305 33
}
## 21.07.02
for {set i 17} {$i < 25} {incr i 1} {
    element dispBeamColumnThermal [expr $i + 2800] [expr $i + 2800] [expr $i + 2801] 5 $UC305 33
    #element dispBeamColumnThermal [expr $i + 2900] [expr $i + 2900] [expr $i + 2901] 5 $UC305 33
}

# shell elements
for {set i 1} {$i <= 78} {incr i} {
    for {set j 1} {$j <= 70} {incr j} {
        set node1 [expr 4000 + $i*1000 + $j]
        set node2 [expr 4000 + ($i - 1)*1000 + $j]
        set node3 [expr $node2 + 1]
        set node4 [expr $node1 + 1]
        set eleID [expr 4000 + ($i - 1)*1000 + $j]
        if {$i <= 17 && $j >= 26 && $j < 36} {
            # opening
        } elseif {$i >= 65 && $j >= 36 && $j < 51} {
            # opening
        } else {
            if {$i <= 16 || $i >= 48} {
                if {!fmod($i,2)} {; #if even
                    set sec $rib
                } else {; #if odd
                    set sec $slab
                }
            } else {
                if {!fmod($i,2)} {
                    set sec $slab
                } else {
                    set sec $rib
                }
            }
            element  ShellNLDKGQThermal  $eleID $node1 $node2 $node3 $node4 $sec
            
        }
    }
}   