## Revision log
## Revised the thermal-load fiber coordinate.
## Revised the shell loading
## 0731 Added the setup recorder

recorder Node -file output/colB1_U3.out -time -node 2709 -dof 3 disp
recorder Node -file output/colB2_U3.out -time -node 2817 -dof 3 disp
recorder Node -file output/colB3_U3.out -time -node 2917 -dof 3 disp
recorder Node -file output/colB4_U3.out -time -node 3009 -dof 3 disp

recorder Node -file output/beam1211_U3.out -time -node 1211 -dof 3 disp
recorder Node -file output/beam1237_U3.out -time -node 1237 -dof 3 disp
recorder Node -file output/beam1264_U3.out -time -node 1264 -dof 3 disp

recorder Element -file output/Beam1238_Tbot.out -time -ele 1238 section $UB610 fiber -298.83    56.9 TempElong;
recorder Element -file output/Beam1238_Ttop.out -time -ele 1238 section $UB610 fiber 298.83     56.9 TempElong;

recorder Element -file output/B1_T.out -time -ele 2708 section $UC305 fiber 34.63750000  0.0 TempElong;
recorder Element -file output/B2_T.out -time -ele 2816 section $UC305 fiber 34.63750000  0.0 TempElong;
recorder Element -file output/B3_T.out -time -ele 2916 section $UC305 fiber 34.63750000  0.0 TempElong;
recorder Element -file output/B4_T.out -time -ele 3008 section $UC305 fiber 34.63750000  0.0 TempElong;
#recorder PVD pvdfile -precision 10 -dT 1 disp
#
recorder Element -file output/column2816_Force.out -time -ele 2816 force
recorder Element -file output/column2817_Force.out -time -ele 2817 force
recorder Element -file output/column2916_Force.out -time -ele 2916 force
recorder Element -file output/column2917_Force.out -time -ele 2917 force

expRecorder Setup -file output/Setup_ctrlforce.out -time -setup 1 ctrlForce
expRecorder Setup -file output/Setup_ctrldisp.out  -time -setup 1 ctrlDisp
expRecorder Setup -file output/Setup_daqforce.out  -time -setup 1 daqForce
expRecorder Setup -file output/Setup_daqdisp.out   -time -setup 1 daqDisp

# Display
set  xPixels 1200;  # height of graphical window in pixels
set  yPixels 800;   # height of graphical window in pixels
set  xLoc1 10;  # horizontal location of graphical window (0=upper left-most corner)
set  yLoc1 10;  # vertical location of graphical window (0=upper left-most corner)
set ViewScale 10;   # scaling factor for viewing deformed shape, it depends on the dimensions of the model
# DisplayModel3D  DeformedShape $ViewScale $xLoc1 $yLoc1  $xPixels $yPixels

###############################################################################################################
# apply UDL Load of 5.81 kN/m2, which is equal to 0.00581 N/mm2

pattern Plain 1 Linear {
    for {set i 1} {$i <= 79} {incr i} {
        for {set j 1} {$j <= 71} {incr j} {
            if {$i <= 17} {
                if {$j <=26 || $j >= 36} {
                    load [expr int (4000 + ($i - 1)*1000 + $j)] 0 0 -540.0 0 0 0
                }
            } elseif {$i > 17 && $i <= 65} {
                load [expr int (4000 + ($i - 1)*1000 + $j)] 0 0 -540.0 0 0 0
            } elseif {$i <= 17} {
                if {$j <=36 || $j >= 51} {
                    load [expr int (4000 + ($i - 1)*1000 + $j)] 0 0 -540.0 0 0 0
                }
            }
        }
    }
    load    2117    0.0 0.0 -235305.0   0.0 0.0 0.0
    load    2217    0.0 0.0 -627480.0   0.0 0.0 0.0
    load    2317    0.0 0.0 -941220.0   0.0 0.0 0.0
    load    2417    0.0 0.0 -470610.0   0.0 0.0 0.0
    load    2517    0.0 0.0 -862785.0   0.0 0.0 0.0
    load    2617    0.0 0.0 -627480.0   0.0 0.0 0.0
    load    2717    0.0 0.0 -627480.0   0.0 0.0 0.0
    load    2825    0.0 0.0 -1568700.0  0.0 0.0 0.0
    load    2925    0.0 0.0 -1568700.0  0.0 0.0 0.0
    load    3017    0.0 0.0 -627480.0   0.0 0.0 0.0
    load    3117    0.0 0.0 -392175.0   0.0 0.0 0.0
    load    3217    0.0 0.0 -522900.0   0.0 0.0 0.0
    load    3317    0.0 0.0 -313740.0   0.0 0.0 0.0
    load    3417    0.0 0.0 -174300.0   0.0 0.0 0.0
    load    3517    0.0 0.0 -104580.0   0.0 0.0 0.0
    load    3617    0.0 0.0 -122010.0   0.0 0.0 0.0
    load    3717    0.0 0.0 -313740.0   0.0 0.0 0.0
}

set tFinal 1.0
puts "Finished preparing model and adding ambient loads."
puts "Proceed to ambient analysis? (y/n) | skip with (s)."
puts "You can also override the analysis total time by entering a double."
puts "You can proceed to all upcoming analyses by entering (a)"
gets stdin Proceed
set proceedAll 0
if {$Proceed == "y" || $Proceed =="Y"} { 
    set columnAnalysis 1
} elseif {$Proceed == "s" || $Proceed =="S"} {
    set columnAnalysis 0
} elseif {$Proceed == "a" || $Proceed =="A"} {
    set columnAnalysis 1
    set proceedAll 1
} elseif {[string is double $Proceed]} {
    set columnAnalysis 1
    set tFinal $Proceed
    puts "Analysis will proceed up to LF = $tFinal as specified by user."
} else {
    puts "User did not wish to proceed. Analysis terminated."
    return
}


########################
# Ambient Solver
########################
#set stepSize 0.04;
#set currentTime 0.0;
#set digits 3
#set ok 0.0;
#constraints Transformation;             
#numberer RCM;           
#system SparseSYM;
##test RelativeNormDispIncr 0.05 1000 2      
#test RelativeNormUnbalance 0.05 1000 0  
#
#algorithm ModifiedNewton;                   
#integrator LoadControl $stepSize;               
#analysis Static;
set stepSize 0.04;
set currentTime 0.0;
set digits 3
set ok 0.0;
constraints Transformation;             
numberer RCM;           
system UmfPack;
#test RelativeNormDispIncr 0.05 1000 2      
#test RelativeNormUnbalance 0.05 1000 0  
#
#algorithm ModifiedNewton;                   
#integrator LoadControl $stepSize;
test FixedNumIter 1 1
integrator LoadControl $stepSize
algorithm Newton               
analysis Static;

if {$columnAnalysis} {
    while {$currentTime < $tFinal && $ok == 0} {
        puts "Attempting analysis for time [expr $currentTime + $stepSize], with step size = $stepSize"
        set ok [analyze 1]
        if {$ok == 0} {
            set currentTime [getTime]
            puts ""; puts "";
            puts "Analysis step successful. Current load factor is $currentTime"
            puts "Column B1's displacement is [expr double(round([lindex [nodeDisp 2709 3] 0]*1e$digits))*1e-$digits] mm."
            puts "Column B2's displacement is [expr double(round([lindex [nodeDisp 2817 3] 0]*1e$digits))*1e-$digits] mm."
            puts "Column B3's displacement is [expr double(round([lindex [nodeDisp 2917 3] 0]*1e$digits))*1e-$digits] mm."
            puts "Column B4's displacement is [expr double(round([lindex [nodeDisp 3009 3] 0]*1e$digits))*1e-$digits] mm."
            puts "Mid beam's displacement is [expr double(round([lindex [nodeDisp 1237 3] 0]*1e$digits))*1e-$digits] mm."
            puts ""; puts "";
        } else {
            puts "Analysis failed at time = $currentTime"
            return
        }
    }
}
loadConst -time 0.0

########################
# Ambient Solver END
########################
#recorder PVD pvdfile -precision 10 -dT 1 disp

#set tFinal 300;         # full time of the applied heating
set tFinal 90;         # full time of the applied heating

puts "Ambient analysis completed.";
if {$proceedAll} { 
    set Proceed "y";
} else {
    puts "Proceed to thermo-mechanical analysis up to time = $tFinal? (y/n)";
    puts "Override total analysis time by entering a double.";
    gets stdin Proceed;
};

if {$Proceed == "y" || $Proceed =="Y"} { 
} elseif {[string is double $Proceed]} {
    set columnAnalysis 1;
    set tFinal $Proceed
    puts "Analysis will proceed up to time = $tFinal as specified by user."
} else {
    puts "User did not wish to proceed. Analysis terminated."
    return
};

puts "Now beginning thermo-mechanical analysis...Hope things don't crash and burn."

pattern Plain 2 Linear {

        # Temperature for the steel frame
        # Comments on 0702: no temp were applied on columns
        #for {set i 12} {$i <= 16} {incr i 1} {
        # #Columns of interest - MUSTESIN
        # #eleLoad -ele $eleTag -beamThermal -source         $fileName                           $y1    $y2   $z1   $z2;
        # #eleLoad -ele [expr 2800 + $i]  -type -beamThermal -source "temps/colB2.dat"     -157.0 157.0 -78.0 78.0;
        #    #eleLoad -ele [expr 2900 + $i]  -type -beamThermal -source "temps/colB2.dat"     -160.0 160.0 -154.0 154.0;
        #}
        eleLoad -ele 2708  -type       -beamThermal -source "temps/colB1.dat"   -160.0 160.0 -154.0 154.0;
        eleLoad -ele 3008  -type       -beamThermal -source "temps/colB1.dat"   -160.0 160.0 -154.0 154.0;
        ## End comments 0702
        
        for {set i 1} {$i <= 20} {incr i 1} {
            eleLoad -ele [expr 1200 + $i] -type        -beamThermal -source "temps/PB2.dat" -176.0 176.0 -86.0 86.0 ;
            eleLoad -ele [expr 1253 + $i] -type        -beamThermal -source "temps/PB2.dat" -176.0 176.0 -86.0 86.0 ;
        }
        for {set i 1} {$i <= 15} {incr i 1} {
            eleLoad -ele [expr 1221 + $i] -type        -beamThermal -source "temps/PB3.dat" -298.0 298.0 -113.0 113.0;
            eleLoad -ele [expr 1237 + $i] -type        -beamThermal -source "temps/PB3.dat" -298.0 298.0 -113.0 113.0;
        }
        
        for {set i 45} {$i <= 53} {incr i 1} {
            if {$i != 49} {
                for {set j 2} {$j <= 7} {incr j 1} {
                    eleLoad -ele [expr 100*$j + $i] -type      -beamThermal -source "temps/SB.dat" -150.1 150.1 -84.0 84.0 ;
                }
                eleLoad -ele [expr 100 + $i] -type     -beamThermal -source "temps/SBEdge.dat" -176.0 176.0 -86.0 86.0 ;
                eleLoad -ele [expr 800 + $i] -type     -beamThermal -source "temps/SBEdge.dat" -176.0 176.0 -86.0 86.0 ;
            }
        }
        
        for {set i 47} {$i <= 54} {incr i 1} {
            for {set j 1} {$j <= 70} {incr j} {
                if {$i == 48 || $i == 50 || $i == 51 || $i == 53} {
                    eleLoad -ele [expr $i*1000 + $j] -type -shellThermal -source "temps/rib.dat" [expr -$halfT-$ribT] [expr $halfT];
                } elseif {$i == 47 || $i == 49 || $i == 52 || $i == 54} {
                    eleLoad -ele [expr $i*1000 + $j] -type -shellThermal -source "temps/flat.dat" [expr -$halfT] [expr $halfT];
                }
            }
        }

}


puts "Applied thermal loading including column temperatures."   

#################################
# Thermo-mechanical Solver
#################################

#set ok 0.0;             # indicating state of the analysis
#set currentTime 0.0;    # time within the fire
#set deltaT 1.0;         # time step for the fire
#set deltaTt $deltaT;    # time step for the fire
#
#constraints Transformation;             
#numberer RCM;   
#system SparseSYM;
##test RelativeNormDispIncr 0.05 1000 2
#test RelativeNormDispIncr 0.05 1000 0
#algorithm KrylovNewton;
#integrator LoadControl $deltaT;
#analysis Static;

set ok 0.0;             # indicating state of the analysis
set currentTime 0.0;    # time within the fire
set deltaT 1.0;         # time step for the fire
set deltaTt $deltaT;    # time step for the fire

constraints Transformation;             
numberer RCM;   
system UmfPack;
#test RelativeNormDispIncr 0.05 1000 2
#test RelativeNormDispIncr 0.05 1000 0
#algorithm KrylovNewton;
#integrator LoadControl $deltaT;
test FixedNumIter 5 1
integrator LoadControl 1
algorithm Newton
analysis Static;

set B2U3 [nodeDisp 2817 3]
set B3U3 [nodeDisp 2917 3]
            
while {$ok == 0 && $currentTime < $tFinal && $deltaT > 0.0001} {
    puts "Attempting analysis for time [expr $currentTime + $deltaT], with time step $deltaT."
    set ok [analyze 1]
    if {$ok != 0} { 
        while {$ok != 0 && $deltaTt >= $deltaT*pow(0.5,5)} { 
            puts "Analysis did not converge with deltaTt = $deltaTt. Halving timestep to [expr $deltaTt/2.0]."
            set deltaTt [expr $deltaTt/2.0]
            integrator LoadControl $deltaTt;
            puts "Attempting analysis for time [expr $currentTime + $deltaTt]"
            set ok [analyze 1]          
        }
        set deltaT $deltaTt
    }
    if {$ok != 0 || $deltaT <= 0.0001 || abs($B2U3) > 100 || abs($B3U3) > 100} {
        if {$deltaT <= 0.0001} {
            puts "Analysis failed at time [getTime] because increment is too small at $deltaT. Last successful step was $currentTime"
        } elseif {abs($B2U3) > 100 || abs($B3U3) > 100} {
            puts "Analysis failed at time [getTime] because displacement at the critical columns is too high. Last successful step was $currentTime"
            puts "Column B2's displacement is [expr double(round([lindex [nodeDisp 2817 3] 0]*1e$digits))*1e-$digits] mm."
            puts "Column B3's displacement is [expr double(round([lindex [nodeDisp 2917 3] 0]*1e$digits))*1e-$digits] mm."
        } else {
            puts "Analysis failed at time [getTime]. Last successful step was $currentTime"
        }
    }   elseif {$ok == 0} {
            set currentTime [getTime]
            puts ""; puts "";
            puts "Analysis for this step succeeded. Current time is $currentTime minutes"
            puts "Column B1's displacement is [expr double(round([lindex [nodeDisp 2709 3] 0]*1e$digits))*1e-$digits] mm."
            puts "B1's temp: [lindex [eleResponse 2708 section 5 fiber 34.6375  0.0 TempElong] 0]C"
            puts "";
            puts "Column B2's displacement is [expr double(round([lindex [nodeDisp 2817 3] 0]*1e$digits))*1e-$digits] mm."
            #puts "B2's temp: [expr double(round([lindex [eleResponse 2808 section 5 fiber 34.6375  0.0 TempElong] 0]*1e$digits))*1e-$digits]C"
            #puts "";
            puts "Column B3's displacement is [expr double(round([lindex [nodeDisp 2917 3] 0]*1e$digits))*1e-$digits] mm."
            #puts "B3's temp: [expr double(round([lindex [eleResponse 2908 section 2 fiber 34.6375  0.0 TempElong] 0]*1e$digits))*1e-$digits]C"
            #puts "";
            puts "Column B4's displacement is [expr double(round([lindex [nodeDisp 3009 3] 0]*1e$digits))*1e-$digits] mm."
            puts "B3's temp: [expr double(round([lindex [eleResponse 3008 section 2 fiber 34.6375  0.0 TempElong] 0]*1e$digits))*1e-$digits]C"
            puts "";
            puts "Mid beam's displacement is [expr double(round([lindex [nodeDisp 1238 3] 0]*1e$digits))*1e-$digits] mm."       
            puts "Top temp: [expr double(round([lindex [eleResponse 1238 section $UB610 fiber 298.83    56.9 TempElong] 0]*1e$digits))*1e-$digits]C"
            puts "Bottom temp: [expr double(round([lindex [eleResponse 1238 section $UB610 fiber -298.83    56.9 TempElong] 0]*1e$digits))*1e-$digits]C"
            set B2U3 [nodeDisp 2817 3]
            set B3U3 [nodeDisp 2917 3]
            puts ""; puts "";
    };
        
};
if {$currentTime == $tFinal} {
puts "Analysis succeeded - current time is $currentTime"
};

#################################
# Thermo-mechanical Solver END
#################################
        
